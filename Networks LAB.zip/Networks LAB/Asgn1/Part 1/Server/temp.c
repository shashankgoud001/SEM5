#include <stdio.h>
#include <stdlib.h>
#define SIZE 500
#define CLIENT_LIMIT 10

int precedence (char c) {
    switch (c)
    {
        case '^' : return 3;
        case '/' : return 2;
        case '*' : return 2;
        case '+' : return 1;
        case '-' : return 1;
        default  : return 0;
    }
}

int isOperand (char c) {
	return (c >= '0' && c <= '9');
}

char* infixtopostfix(char buf[]){
    char s[SIZE];
    char* res = (char*)malloc(SIZE*sizeof(char));
    int i = 0,j=0,k=0,flag=0;
    while(buf[i]!='\n'&&buf[i]!='\0'){
        if(buf[i]==' ') i++,res[k++]=' ',flag=0;
        else if(isOperand(buf[i])){
            res[k++] = buf[i++];
            flag = 1;
        }else{
            if(flag == 1) res[k++] = ' ';
            flag = 0;
            if(buf[i]=='('){
                s[j++] = buf[i++];
            }else if(buf[i]==')'){
                while(j&&s[j-1]!='('){
                    res[k++] = s[j-1];
                    j--;
                }
                --j;
            }else{
                while(j&&precedence(buf[i])<=precedence(s[j-1])){
                    res[k++] = s[j-1];
                    j--;
                }
                s[j++] = buf[i++];
            }
        }
    }
    if(flag) res[k++] = ' ';
    while(j){
        res[k++] = s[j-1];
        j--;
    }
    return res;
}

int main(){
    char temp[] = "4 * 5 * 10\n";
    printf("%s\n",infixtopostfix(temp));
    
    return 0;
}