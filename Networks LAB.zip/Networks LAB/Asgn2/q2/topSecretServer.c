#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <dirent.h> 
#define SIZE 100
#define MAX_SIZE 500
#define BUF_SIZE 40
#define PORT_NO 2000

void send_Message(int newsockfd,char buf[],char command[]){
	strcat(command,"\0");
	// bzero(buf,BUF_SIZE);
	int l = strlen(command),i=0,j=0;
	while(j<=l){
		while(i<BUF_SIZE&&j<=l){
			buf[i++]=command[j++];
		}
		if(j>=l) send(newsockfd,buf,strlen(buf)+1,0);
		else send(newsockfd,buf,strlen(buf),0);
	}
}

void recieve_Message(int newsockfd,char buf[],char command[]){
	bzero(command,MAX_SIZE);
	bzero(buf,BUF_SIZE);
	int t;
	while((t=recv(newsockfd,buf,BUF_SIZE,0))>0){
		strcat(command,buf);
		if(buf[t-1]=='\0') break;
	}
}


int verifyClient(char user[]){
	FILE *file;
    file = fopen("users.txt", "r");

    if (file == NULL) {
        printf("Error in opening the file users.txt\n");
        return 0;
    }

    char line[50];
    int found = 0;
    while (fgets(line, sizeof(line), file)) {  // Read one line at a time
		if(line[strlen(line)-1]=='\n'){
			line[strlen(line)-1]='\0';
		}
        if (strcmp(line, user)==0) { 
            printf("Username found\n");
			fclose(file);
			return 1;
        }
    }

    if (!found) {
        printf("Username not found\n");
    }

    fclose(file);
	return 0;
}



int check(char* command){
	int l = strlen(command),i=0;
	if(command[0]=='p'){
		if(command[1]=='w'){
			if(command[2]=='d'){
				printf("Came HERE TO BEFORE PWD\n");
				if(l==3) return 1;
				printf("CAME HERE TO AFTER PWD\n");
			}
		}
	}else if(command[0]=='d'){
		if(command[1]=='i'){
			if(command[2]=='r'){
				return 2;
				printf("YO YO YO \n");
			}
		}
	}else if(command[0]=='c'){
		if(command[1]=='d'){
			printf("UMM\n");
			if(command[2]==' ') return 3;
			printf("Dam\n");
		}
	}
	printf("WELL\n");
	return -1;
}

char* show_pwd(){
	char *p = (char*)malloc(300*sizeof(char));
	char cwd[256];
	if (getcwd(cwd, sizeof(cwd)) == NULL)
	{
    //   perror("getcwd() error");
		printf("WHY AM I HERE ?\n");

	  return "####\0";
	}
    else{
		strcat(p,cwd);
		strcat(p,"\0");
		printf("%s\n",p);
		return p;

	}

}

char* show_dir(char* command){
	int l = strlen(command);
	char* path = (char*)malloc(l*sizeof(char));
	path[0]='.';
	path[1] = '\0';
	if(l>3){
		for(int i = 3;i<l;++i){
			path[i-3] = command[i];
		}
		path[l-3] = '\0';
	}
		struct dirent *de;

    DIR *dr = opendir(path); 
  
    if (dr == NULL)
    { 
        // printf("Could not open current directory" ); 
        // return 0; 
		return "####\0";
    }  
    while ((de = readdir(dr)) != NULL) 
            printf("%s\n", de->d_name); 
	return "Done\0";
}

char* change_dir(char* command){
	int l = strlen(command);
	char* path = (char*)malloc(l*sizeof(char));
	for(int i = 3;i<l;++i){
		path[i-3] = command[i];
	}
	path[l-3] = '\0';
	int ch=chdir(path);
	if(ch<0)
    	return "####\0";
    else
		return "Changed the directory successfully\0";
}

char* perform_service(char* command){

	switch (check(command))
	{
	case 1:
		return show_pwd();
		break;
	case 2:
		return show_dir(command);
		break;
	case 3:
		return change_dir(command);
		break;
	default:
		return "$$$$\0";
		break;
	}
}
void change(char a[]){
    for(int i = 0;i<BUF_SIZE;++i){
        a[i]='@';
    }
}
int main()
{
	int			sockfd, newsockfd ; 
	int			clilen;
	struct sockaddr_in	cli_addr, serv_addr;

	int i,j,k,f,t=1;
	char buf[SIZE],command[MAX_SIZE],*temp = (char*)malloc(sizeof(char)*MAX_SIZE);		

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Cannot create socket\n");
		exit(0);
	}

	serv_addr.sin_family		= AF_INET;
	serv_addr.sin_addr.s_addr	= INADDR_ANY;
	serv_addr.sin_port		= htons(PORT_NO);


	if (bind(sockfd, (struct sockaddr *) &serv_addr,
					sizeof(serv_addr)) < 0) {
		printf("Unable to bind local address\n");
		exit(0);
	}

	listen(sockfd, 5); 
	while (1) {
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,
					&clilen) ;

		if (newsockfd < 0) {
			printf("Accept error\n");
			exit(0);
		}
		if (fork() == 0) {
			close(sockfd);
			bzero(buf,BUF_SIZE);
			bzero(command,MAX_SIZE);
			strcpy(buf,"LOGIN:\0");
			send(newsockfd, buf, strlen(buf)+1, 0); //login
			 //username
			while((t=recv(newsockfd, buf, BUF_SIZE, 0))>0){
				strcat(command,buf);
				i=0;
				printf("I am ");
				if(buf[t-1]=='\0') break;
				bzero(buf,BUF_SIZE);
			}
			if(verifyClient(command)){
				bzero(buf,BUF_SIZE);
				strcpy(buf,"FOUND");
				printf("lets know what hapened hmm");
				send(newsockfd,buf,strlen(buf)+1,0);
				printf("It went\n");
				bzero(command,MAX_SIZE);
				while(t>0){
					bzero(buf,BUF_SIZE);

					while((t=recv(newsockfd, buf, BUF_SIZE, 0))>0){
						strcat(command,buf);
						i=0;
						k=0;
						printf("t : %d\n",t);
						printf("%s\t%s\n",command,buf);
						if(buf[t-1]=='\0') break;
						bzero(buf,BUF_SIZE);
					}
					printf("WAYYYYYYY above herererererere\n");
					printf("%s\n",command);

					printf("%c %c %c %lu\n",command[0],command[1],command[2],strlen(command));
					temp = perform_service(command);
					bzero(command,MAX_SIZE);
					strcpy(command,temp);
					printf("%s\n",command);

					i=0;j=0;
					k=strlen(command);
					printf("len : %d\n",k);
					bzero(buf,BUF_SIZE);
					strcat(buf,"DONE");
					t = send(newsockfd,buf,strlen(buf)+1,0);
					printf("t : %d\n",t);
					while(j<k){
						i=0;
						while(i<BUF_SIZE&&j<k){
							buf[i++]=command[j++];
						}
						buf[i] = '\0';
						if(j==k){
							send(newsockfd,buf,strlen(buf)+1,0);
							break;
						}
						else send(newsockfd,buf,strlen(buf),0);
						printf("%s\n",buf);
						printf("Sent once\n");
						printf("%d\t%d\t%d\n",i,j,k);
					}
					printf("my work is done\n");
				}
			}else{
				bzero(buf,BUF_SIZE);
				strcpy(buf,"NOT-FOUND\0");
				send(newsockfd,buf,strlen(buf)+1,0);
			}
			close(newsockfd);
			exit(0);
		}

		close(newsockfd);
	}
	return 0;
}
			

