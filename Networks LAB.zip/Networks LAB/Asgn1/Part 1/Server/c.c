#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 500    
struct stack_char {
  char STACK_CHAR[SIZE];
  int top;
};


void initialise(struct stack_char *s) {
  s->top = -1;
}


int isfull(struct stack_char *s) {
  if (s->top == SIZE - 1)
    return 1;
  else
    return 0;
}


int isempty(struct stack_char *s) {
  if (s->top == -1)
    return 1;
  else
    return 0;
}


void push(struct stack_char *s, char data) {
  if (isfull(s)) {
    printf("FULL\n");
  } else {
    s->top++;
    s->STACK_CHAR[s->top] = data;
  }

}


void pop(struct stack_char *s) {
  if (isempty(s)) {
    printf("EMPTY \n");
  } else {
    s->top--;
  }
}

char peek(struct stack_char *s){
  if(s->top==-1) return '\0';
  return s->STACK_CHAR[s->top];
}


int precedence (char c) {
	if (c == '/' || c == '*') {
		return 1;
    }
	else if (c == '+' || c == '-') {
		return 1;
    }
	else {
        return 0;
    }
}


int isOperand (char c) {
	return ((c >= '0' && c <= '9')||c=='.');
}


char* infixToPostfix (char buf[], int n) {
	struct stack_char* s = (struct stack_char*)malloc(sizeof(struct stack_char)); 
	initialise(s);
	char* postFix = (char*)malloc(SIZE*sizeof(char));
	int index = 0;

	for(int i = 0; i < n; i++) {
    if(buf[i]==' ') continue;
    else if(buf[i]=='\n') continue;
    else if(buf[i]=='?') break;
		else if (isOperand(buf[i])) {
            postFix[index++] = buf[i];
        }
		else if (buf[i] == '(') {
			      push(s,buf[i]);
        }
		else if (buf[i] == ')') {
			while(peek(s) != '(') {
				postFix[index++] = peek(s);
				pop(s);
			}
			pop(s);
		}
		else {
      postFix[index++] = ' ';
			while (!isempty(s) && precedence(buf[i]) <= precedence(peek(s))) {
				postFix[index++] = peek(s);
				pop(s);
			}
			push(s,buf[i]);
		}
	}

	while (!isempty(s)) {
		postFix[index++] = peek(s);
    pop(s);
	}

	return postFix;
}


struct stack_float {
  float STACK_FLOAT[SIZE];
  int top;
};

void initialise_stack_float(struct stack_float *s) {
  s->top = -1;
}


int isfull_(struct stack_float *s) {
  return (s->top == SIZE - 1);
}


int isempty_(struct stack_float *s) {
  return (s->top == -1);
}


void push_(struct stack_float *s, float data) {
  if (isfull_(s)) {
    printf("FULL\n");
  } else {
    s->top++;
    s->STACK_FLOAT[s->top] = data;
  }
}


void pop_(struct stack_float *s) {
  if (isempty_(s)) {
    printf("EMPTY\n");
  } else {

    s->top--;
  }
}

float peek_(struct stack_float *s){
  if(s->top==-1) return 0;
  return s->STACK_FLOAT[s->top];
}

float evaluatePostfix(char* exp)
{

    struct stack_float* stack = (struct stack_float*)malloc(sizeof(struct stack_float));
    initialise_stack_float(stack);

    int i=0;
 
    while (exp[i]!='\0'&&exp[i]!='?')
    {
      if(exp[i]==' '||exp[i]=='\n'){
       i++;
       continue;

      }
        float point = 0,temp=0;
        if(isOperand(exp[i])){

        
          while (isOperand(exp[i])){
            // printf("%f ",temp);
              if(exp[i]=='.') point = 10;
              else{
                if(point){
                  temp  += (exp[i]-'0')*1.0/point;
                  point *=10;
                }else{
                  temp = 10*temp + (exp[i]-'0'); 
                }
              }
              i++;
          }
          push_(stack, temp);
          }else
          {
              float val1 = peek_(stack);
              pop_(stack);
              float val2 = peek_(stack);
              pop_(stack);
              switch (exp[i])
              {
              case '+': push_(stack, val2 + val1); break;
              case '-': push_(stack, val2 - val1); break;
              case '*': push_(stack, val2 * val1); break;
              case '/': push_(stack, val2/val1); break;
              }
              i++;
        }
    }

    return peek_(stack);
}
int main(){
    // char temp[] = "90 + 90 + 90";
    char temp[SIZE];
    scanf("%[^\n]s",temp);
    int n = strlen(temp);
    char* t = infixToPostfix(temp,n);
    printf("%s\n",t);
    // scanf("%d",&n);
    printf("%f\n",evaluatePostfix(t));
    return 0;
}