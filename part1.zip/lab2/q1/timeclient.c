//  ************* Time Client UDP *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <poll.h>

int main()
{
    int sockfd;
    struct sockaddr_in servaddr;

    // Creating a socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("[-] Error in Socket Creation");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Setting the values of attributes
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(8181);
    inet_aton("127.0.0.1", &servaddr.sin_addr);

    socklen_t len;
    char buf[30]; // buffer for transfers
    memset(buf, 0, sizeof(buf));
    char *req = "What's the time now?\n";

    // for countdown of 3 seconds
    struct pollfd count_down;
    count_down.fd = sockfd;
    count_down.events = POLLIN;

    int iter = 5; // for iterations
    int flag = 0; // to check if the request was served or not
    while (iter--)
    {
        // sending request to server
        sendto(sockfd, (const char *)req, strlen(req)+1, 0, (const struct sockaddr *) &servaddr, sizeof(servaddr));
        if (poll(&count_down, 1, 3000) > 0)
        {
            // when received "time" from server, breaking the loop
            recvfrom(sockfd, (char *) buf, sizeof(buf), 0, (struct sockaddr *)& servaddr, &len);
            flag = 1; // setting the flag to 1
            break;
        }
    }

    // if the request is not served
    if (!flag)
    {
        printf("Timeout Exceeded\n");
        exit(0);
    }

    // if the request is served, print the time
    printf("Current time is: %s\n", buf);

    // closing the socket
    close(sockfd);

    return 0;
}