#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#define SIZE 5000
#define MAX_SIZE 1000
#define  BUF_SIZE 100
#define PORT 21000

int send_Message(int newsockfd,char buf[],char command[]){
	strcat(command,"\0");
	int l = strlen(command),i=0,j=0,c=0;
	while(j<l){
		bzero(buf,BUF_SIZE);
		i=0;
		while(i<BUF_SIZE&&j<=l){
			buf[i++]=command[j++];
		}
		if(j>=l) c +=send(newsockfd,buf,strlen(buf)+1,0);
		else c += send(newsockfd,buf,strlen(buf),0);
	}
    return c;
}

int send_Message_util(int newsockfd,char buf[],char command[]){
	strcat(command,"\0");
	bzero(buf,BUF_SIZE);
	int l = strlen(command),i=0,j=0,c=0;
	while(j<l){
		i=0;
		while(i<BUF_SIZE&&j<l){
			buf[i++]=command[j++];
		}
		c+=send(newsockfd,buf,strlen(buf),0);
	}
    return c;
}

int recieve_Message(int newsockfd,char buf[],char command[]){
	bzero(command,MAX_SIZE);
	bzero(buf,BUF_SIZE);
	int t,c=0;
	while((t=recv(newsockfd,buf,BUF_SIZE,0))>0){
		strcat(command,buf);
        c+=t;
		if(buf[t-1]=='\0') break;
	}
    return c;
}
// int count_number_of_bytes_asdqwd(char buf[]){
//     bzero(buf,BUF_SIZE);
//     FILE *infile;
//     char infilename[] = "wallpaper.jpeg";

//     infile = fopen(infilename, "rb");
//     if (infile == NULL) {
//         printf("Error: could not open file %s", infilename);
//         return 1;
//     }
//     int count  = 0,t;
//     while ((t=fread(buf,1, BUF_SIZE,  infile) )>0) {
//         count+=t;
//     }

//     if (ferror(infile)) {
//         printf("Error reading file %s", infilename);
//     }

//     fclose(infile);
//     bzero(buf,BUF_SIZE);
//     return count*BUF_SIZE;
// }
// int send_image(int newsockfd,char buf[],char infilename[]){
//     bzero(buf,BUF_SIZE);
//     FILE *infile, *outfile;
//     char outfilename[] = "output.jpeg";
//     // char infilename[] = "wallpaper.png";
//      outfile = fopen(outfilename, "wb");
//     if (outfile == NULL) {
//         printf("Error: could not create file %s", outfilename);
//         fclose(infile);
//         return 1;
//     }
//     infile = fopen(infilename, "rb");
//     if (infile == NULL) {
//         printf("Error: could not open file %s", infilename);
//         return 1;
//     }
//     int t;
//     while ((t=fread(buf, 1,BUF_SIZE, infile)) >0) {
//         send(newsockfd,buf,t,0);
//         fwrite(buf, 1,BUF_SIZE, outfile);
//     }
//     fclose(infile);
//     fclose(outfile);
//     if (ferror(infile)) {
//         printf("Error reading file %s", infilename);
//     }
   
//     printf("Sent image\n");
//     bzero(buf,BUF_SIZE);
//     return 1;
// }
// void handle_image_sending(){
//     recv(newsockfd, request, MAX_SIZE, 0);
// 		printf("%s\n", request);
//         int c = count_number_of_bytes(buf);
//         sprintf(response,"HTTP/1.1 200 OK\nContent-Type: image/jpeg\nContent-Length: %d\n\n",c);
// 		send(newsockfd, response, strlen(response), 0);
//         char name[] = "wallpaper.jpeg";
//         send_image(newsockfd,buf,name);
// }
// char name[]="Assgn-4.pdf";
        // int c = count_number_of_bytes(buf,name);
		// sprintf(response,"HTTP/1.1 200 OK\nContent-Type: application/pdf\nContent-Length: %d\n\n",c);
		// // // sprintf(response,"HTTP/1.1 200 OK\nContent-Type: application/pdf\nContent-Length: %d\n\n",c);
        // printf("Count : %d\n",c);
        // send(newsockfd, response, strlen(response), 0);
        // send_any_file(newsockfd,buf,name);
int count_number_of_bytes(char buf[],char filename[]){
    bzero(buf,BUF_SIZE);
    FILE *infile;
    infile = fopen(filename, "rb");
    if (infile == NULL) {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    int t;
    int count =0;
    printf("%s\n",filename);
    while ((t=fread(buf, 1,BUF_SIZE, infile)) >0) {
        count += t;
    }
    fclose(infile);
    if (ferror(infile)) {
        printf("Error reading file %s", filename);
    }
    printf("Count : %d\n",count);
    return count;
}
int send_any_file(int newsockfd,char buf[],char filename[]){
    bzero(buf,BUF_SIZE);
    FILE *infile, *outfile;
    char outfilename[] = "output";
    infile = fopen(filename, "rb");
    outfile = fopen(outfilename,"wb");
    if (infile == NULL) {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    int t;
    while ((t=fread(buf, 1,BUF_SIZE, infile)) >0) {
        send(newsockfd,buf,t,0);
        fwrite(buf,1,t,outfile);
    }
    fclose(infile);
    fclose(outfile);
    if (ferror(infile)) {
        printf("Error reading file %s", filename);
    }
    bzero(buf,BUF_SIZE);
    return 1;
}
int main()
{
	int			sockfd, newsockfd ; /* Socket descriptors */
	int			clilen;
	struct sockaddr_in	cli_addr, serv_addr;
    char *request = (char*)malloc(SIZE*sizeof(char));
    char *response = (char*)malloc(SIZE*sizeof(char));
	int i;
	char buf[MAX_SIZE];	
    bzero(buf,MAX_SIZE);
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Cannot create socket\n");
		exit(0);
	}


	serv_addr.sin_family		= AF_INET;
	serv_addr.sin_addr.s_addr	= INADDR_ANY;
	serv_addr.sin_port		= htons(PORT);


	if (bind(sockfd, (struct sockaddr *) &serv_addr,
					sizeof(serv_addr)) < 0) {
		perror("Unable to bind local address\n");
		exit(0);
	}

	listen(sockfd, 5); 
	while (1) {
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,
					&clilen) ;

		if (newsockfd < 0) {
			perror("Accept error\n");
			exit(0);
		}



		recv(newsockfd, request, MAX_SIZE, 0);
		printf("%s\n", request);
        // char name[]="Assgn-4.pdf";
        char name[]="/home/venkata/Downloads/screenshot_methods.jpg";
        int c = count_number_of_bytes(buf,name);
		sprintf(response,"HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n",c);
		// // sprintf(response,"HTTP/1.1 200 OK\nContent-Type: application/pdf\nContent-Length: %d\n\n",c);
        printf("Count : %d\n",c);
        send(newsockfd, response, strlen(response), 0);
        send_any_file(newsockfd,buf,name);
		close(newsockfd);
        printf("Closed\n");
	}
	return 0;
}
			

