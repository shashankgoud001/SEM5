//  ************* Evaluate Arithmatic Expression Server *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 1
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

float numbers[100];
int tn = -1, to = -1;
char op[100];
int is_op = 1;

void push_num(float n)
{
    numbers[++tn] = n;
}

void push_op(char ch)
{
    op[++to] = ch;
}

float pop_num()
{
    return numbers[tn--];
}

char pop_op()
{
    return op[to--];
}

float infix_eval()
{
    float x, y;
    char ope;

    x = pop_num();
    y = pop_num();

    ope = pop_op();

    switch (ope)
    {
        case '+':
            return x+y;
        case '-':
            return y-x;
        case '*':
            return x*y;
        case '/':
            if (x == 0.0)
            {
                printf("\n ^^^^ Can not divide by 0 ^^^^\n");
                exit(0);
            }
            else    return y/x;
    }

    return 0;
}

int isdigit(char c)
{
    return (c == '.' || ('0' <= c && c <= '9'));
}

int is_operator(char ch)
{
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

int precedence(char c)
{
    switch (c)
    {
        case '+':
            return 1;
        case '-':
            return 1;
        case '*':
            return 2;
        case '/':
            return 2;
    }
    return -1;
}

float eval(char exp[200])
{
    float output;

    for (int i = 0; exp[i] != '\0'; i++)
    {
        char c = exp[i];
        if (isdigit(c) != 0 || c == '-' && is_op == 1)
        {
            float num = 0;
            int flag = 0;
            int neg = 0;
            float decimal_part = 0, k = 0.1;
            if (c == '-')
            {
                neg = 1;
                i++;
                c = exp[i];
            }
            while (isdigit(c))
            {
                if (c == '.')
                {
                    flag = 1;
                    i++;
                    if (i == strlen(exp))
                        break;
                    c = exp[i];
                    continue;
                }
                if (flag == 0)
                    num = num*10 + c-'0';
                else
                {
                    decimal_part += k*(c-'0');
                    k/=10;
                }
                i++;
                if (i < strlen(exp))
                    c = exp[i];
                else break;
            }
            i--;
            float ins_val = num+decimal_part;
            
            if (neg)
                ins_val = -ins_val;

            push_num(ins_val);
            is_op = 0;
        }
        else if (c == '(')
        {
            is_op = 1;
            push_op(c);
        }
        else if (c == ')')
        {
            is_op = 1;
            while (op[to] != '(')
            {
                int r = infix_eval();
                push_num(r);
            }
            pop_op();
        }
        else if (is_operator(c))
        {
            is_op = 1;
            while (to != -1 && precedence(c) <= precedence(op[to]))
            {
                output = infix_eval();
                push_num(output);
            }
            push_op(c);
        }
    }

    while (to != -1)
    {
        output = infix_eval();
        push_num(output);
    }

    return pop_num();
}

void revstr(char *str1)
{
    int i, len, temp;
    len = strlen(str1);
    for (i = 0; i < len/2; i++)
    {
        temp = str1[i];
        str1[i] = str1[len - i - 1];
        str1[len - i - 1] = temp;
    }
}

void float_to_string(float val, char arr[100])
{
    int f = val;
    val -= f;
    arr[0] = '\0';
    char int_str[15];
    int neg = 0;
    int i = 0;
    if (f < 0)
    {
        f = -f;
        neg = 1;
    }

    if (f == 0)
    {
        int_str[i++] = '0';
    }
    
    while (f)
    {
        int_str[i++] = '0' + f%10;
        f /= 10;
    }

    if (neg)
    {
        int_str[i++] = '-';
    }
    
    int_str[i] = '\0';
    revstr(int_str);

    strcat(arr, int_str);
    arr[i++] = '.';

    for (int j = 0; j < 6; j++)
    {
        f = val*10;
        arr[i++] = '0' + f;
        val = val*10-f;
    }
    arr[i] = '\0';
}

int main()
{
    int sockfd, newsockfd;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    char buf[100];

    // creating a new socket for the server
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[-] Error in creating a socket\n");
        exit(0);
    }

    // setting the socket attributes
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(20000);

    // binding the socket to the port
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("[-] Error to bind local address\n");
        exit(0);
    }

    // listening to the clients and starting the server
    listen(sockfd, 5);

    while (1)
    {
        clilen = sizeof(cli_addr);
        printf("[+] Waiting for connection...\n");

        // accepting a new client request
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        if (newsockfd < 0)
        {
            perror("[-] Accept error\n");
            exit(0);
        }
        while (1)
        {
            char expression[200];
            int recv_size;
            bzero(buf, 100);
            expression[0] = '\0';
            int done = 0;

            // recieving the expression in chunks
            while ((recv_size = recv(newsockfd, buf, 100, 0)) > 0)
            {
                int len = strlen(buf);
                strcat(expression, buf);

                for (int i = 0; i < len; i++)
                    if (buf[i] == '\n')
                    {
                        done = 1;
                        break;
                    }
                
                // printf("chunk: %s\n", buf);
                bzero(buf, 100);
                if (done)
                    break;
            }

            if (strcmp(expression, "-1\n") == 0)
                break;
            
            int tot_len = strlen(expression);
            expression[tot_len-1] = '\0';
            // evaluting the expression
            float num_ans = eval(expression);

            // char ans[100];
            // printf("value is: %f\n", num_ans);

            // converting the floating point number to string
            // float_to_string(num_ans, ans);
            sprintf(buf, "%f\n", num_ans);
            // strcpy(buf, ans);

            // sending the answer to the client
            int sent_byte = send(newsockfd, buf, strlen(buf)+1, 0);
        }

        // closing the connection with current client
        close(newsockfd);

        printf("\n[+] Served the client request\n\n");
    }

    // closing the server
    close(sockfd);
    return 0;
}   