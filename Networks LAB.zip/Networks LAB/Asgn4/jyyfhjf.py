# Training Loop for model D
train_loss_history = []
val_loss_history = []
train_acc_history = []
val_acc_history = []
total_step = len(train_loader)
for epoch in range(num_epochs):
    train_loss = 0.0
    train_total = 0
    train_correct = 0
    val_loss = 0.0
    val_total = 0
    val_correct = 0
    for i, (images, labels) in enumerate(train_loader):
        # Forward pass
        outputs = modelA(images.reshape(-1, 28*28))
        loss = criterion(outputs, labels)

        # Backward and optimize
        optimizerA.zero_grad()
        loss.backward()
        optimizerA.step()

        # Track training loss and accuracy
        train_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        train_total += labels.size(0)
        train_correct += (predicted == labels).sum().item()

        # Print training metrics
        if (i+1) % 100 == 0:
            print ('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, i+1, total_step, loss.item()))
        # Evaluate network on validation set and track metrics
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = modelA(images.reshape(-1, 28*28))
            loss = criterion(outputs, labels)
            val_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            val_total += labels.size(0)
            val_correct += (predicted == labels).sum().item()

  # Record metrics
    train_loss_history.append(train_loss / len(train_loader))
    val_loss_history.append(val_loss / len(val_loader))
    train_acc_history.append(100 * train_correct / train_total)
    val_acc_history.append(100 * val_correct / val_total)

# Print validation metrics
    print('Epoch [{}/{}], Train Loss: {:.4f}, Val Loss: {:.4f}, Train Acc: {:.2f}%, Val Acc: {:.2f}%'
          .format(epoch+1, num_epochs, train_loss_history[-1], val_loss_history[-1], train_acc_history[-1], val_acc_history[-1]))
            
