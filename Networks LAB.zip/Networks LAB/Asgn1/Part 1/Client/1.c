


struct stack_float {
  float STACK_FLOAT[SIZE];
  int top;
};

void initialise_stack_float(struct stack_float *s) {
  s->top = -1;
}


int isfull_(struct stack_float *s) {
  return (s->top == SIZE - 1);
}


int isempty_(struct stack_float *s) {
  return (s->top == -1);
}


void push_(struct stack_float *s, float data) {
  if (isfull_(s)) {
    printf("FULL\n");
  } else {
    s->top++;
    s->STACK_FLOAT[s->top] = data;
  }
}


void pop_(struct stack_float *s) {
  if (isempty_(s)) {
    printf("EMPTY\n");
  } else {

    s->top--;
  }
}

float peek_(struct stack_float *s){
  if(s->top==-1) return 0;
  return s->STACK_FLOAT[s->top];
}