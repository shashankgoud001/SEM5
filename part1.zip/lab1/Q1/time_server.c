//  ************* Time Server *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 1
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

int main()
{
    int sockfd, newsockfd;
    socklen_t clilen;
    struct sockaddr_in cli_addr, serv_addr;
    char buf[100];

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[-] Error in creating a socket\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(20000);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("[-] Error to bind local address\n");
        exit(0);
    }

    listen(sockfd, 5);

    while (1)
    {
        clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        if (newsockfd < 0)
        {
            perror("[-] Accept error\n");
            exit(0);
        }

        time_t time_raw;
        struct tm* curr_time;

        time(&time_raw);
        curr_time = localtime(&time_raw);

        strcpy(buf, asctime(curr_time));
        send(newsockfd, buf, strlen(buf)+1, 0);

        close(newsockfd);
    }

    close(sockfd);

    return 0;
}