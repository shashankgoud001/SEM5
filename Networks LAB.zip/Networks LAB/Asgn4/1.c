#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *infile, *outfile;
    char infilename[] = "wallpaper.jpeg";
    char outfilename[] = "output.jpeg";
    int buffer_size = 300;
    char buffer[buffer_size];
    int count =0;
    infile = fopen(infilename, "rb");
    if (infile == NULL) {
        printf("Error: could not open file %s", infilename);
        return 1;
    }

    outfile = fopen(outfilename, "wb");
    if (outfile == NULL) {
        printf("Error: could not create file %s", outfilename);
        fclose(infile);
        return 1;
    }
    int t;
    while ((t=fread(buffer, 1,buffer_size, infile))>0) {
        count+=sizeof(buffer);

        fwrite(buffer,1,t, outfile);
    }
    // printf("%d\n",buffer_size*count);
    printf("%d\n",count);
    if (ferror(infile)) {   
        printf("Error reading file %s", infilename);
    }
    if (ferror(outfile)) {
        printf("Error writing file %s", outfilename);
    }

    fclose(infile);
    fclose(outfile);

    return 0;
}
