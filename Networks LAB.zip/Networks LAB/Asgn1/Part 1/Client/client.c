#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SIZE 500
#define BUF_SIZE 20
int main(){
    while(1){

    
    int sockfd;
    struct sockaddr_in server_address;

    int i,flag=0;
    char buf[BUF_SIZE],req[SIZE];

    if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0){
        perror("Unable to create socket\n");
        exit(0);
    }

    server_address.sin_family = AF_INET;
    inet_aton("127.0.0.1",&server_address.sin_addr);
    server_address.sin_port = htons(20000);

    if((connect(sockfd,(struct sockaddr *) &server_address,sizeof(server_address))<0)){
        perror("Unable to connect to server\n");
        exit(0);
    }
    for(i=0; i < BUF_SIZE; i++) buf[i] = '\0';
    for(i=0; i < SIZE; i++) req[i] = '\0';
    
    printf("Please enter the expression to evaluate : \n");
    // scanf("%[^\n]s",buf);
    
    while(1){
        fgets(buf,BUF_SIZE,stdin);
        if(flag==0&&(strlen(buf)>=2&&buf[0]=='-'&&buf[1]=='1')){
            break;
        }
        printf("%s\n",buf);
        strcat(req,buf);
        if(buf[strlen(buf)-2]=='?') break;
        bzero(buf,BUF_SIZE);
        flag = 1;
     }
    if(strlen(buf)>=2&&buf[0]=='-'&&buf[1]=='1'){
        break;
    }
    // getchar();
    strcat(req,"\0");
    send(sockfd,req,strlen(req)+1,0);
    recv(sockfd,req,SIZE,0);
    printf("%s",req);

    close(sockfd);
    }   
    return 0;
}