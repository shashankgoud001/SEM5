#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SIZE 500

int main(){
    while(1){

    
    int sockfd;
    struct sockaddr_in server_address;

    int i;
    char buf[SIZE];

    if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0){
        perror("Unable to create socket\n");
        exit(0);
    }

    server_address.sin_family = AF_INET;
    inet_aton("127.0.0.1",&server_address.sin_addr);
    server_address.sin_port = htons(20000);

    if((connect(sockfd,(struct sockaddr *) &server_address,sizeof(server_address))<0)){
        perror("Unable to connect to server\n");
        exit(0);
    }
    for(i=0; i < SIZE; i++) buf[i] = '\0';
    printf("Please enter the expression to evaluate : \n");
    scanf("%[^\n]s",buf);
    if(strlen(buf)>=2&&buf[0]=='-'&&buf[1]=='1'){
        break;
    }
    getchar();
    strcat(buf,"\0");
    send(sockfd,buf,strlen(buf)+1,0);
    recv(sockfd,buf,SIZE,0);
    printf("%s",buf);

    close(sockfd);
    }   
    return 0;
}