//  ************* Time Load Balancer *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 3
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>

// function to send the expression in chunks of size atmost 50
void send_exp(int sockfd, char *expression, char *buf)
{
    int len = strlen(expression);
    int i = 0, pos = 0, done = 0;
    while (pos < len)
    {
        bzero(buf, 100);
        while (i < 100)
        {
            buf[i++] = expression[pos++];
            if (expression[pos] == '\0')
            {
                done = 1;
                break;
            }
        }

        if (done)
        {
            buf[i] = '\0';
            send(sockfd, buf, strlen(buf)+1, 0);
            break;
        }
        i = 0;
        send(sockfd, buf, strlen(buf)+1, 0);
    }
}

// function to receive the expression in chunks of size atmost 100
void recv_exp(int sockfd, char *buf, char *expression)
{
    bzero(expression, 1000);
    while (1)
    {
        int n = recv(sockfd, buf, 100, 0);
        strcat(expression, buf);
        if (buf[n-1] == '\0')
            break;
    }
}

int main(int argc, char *argv[])
{
    int sock_as_cli1, sock_as_cli2, sock_as_serv, newsockfd;
    socklen_t cli_len;
    struct sockaddr_in serv1_addr, serv2_addr;
    char buf[100], expression[1000];
    struct sockaddr_in serv_addr, cli_addr;

    if ((sock_as_serv = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[-] Error in creating a socket\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(atoi(argv[1]));

    if (bind(sock_as_serv, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("[-] Error to bind local address\n");
        exit(0);
    }

    listen(sock_as_serv, 5);

    serv1_addr.sin_family = AF_INET;
    inet_aton("127.0.0.1", &serv1_addr.sin_addr);
    serv1_addr.sin_port = htons(atoi(argv[2]));

    serv2_addr.sin_family = AF_INET;
    inet_aton("127.0.0.1", &serv2_addr.sin_addr);
    serv2_addr.sin_port = htons(atoi(argv[3]));

    char req[] = "Send Load";

    // for countdown of 5 seconds
    struct pollfd count_down;
    count_down.fd = sock_as_serv;
    count_down.events = POLLIN;

    int flag = 0, load1, load2, t_intital, t_curr, t_diff = 0;

    while (1)
    {
        if (flag == 0)
        {
            if ((sock_as_cli1 = socket(AF_INET, SOCK_STREAM, 0)) < 0)
            {
                perror("[-] Error in creating a socket\n");
                exit(0);
            }

            if ((connect(sock_as_cli1, (struct sockaddr *) &serv1_addr, sizeof(serv1_addr)) < 0))
            {
                perror("[-] Unable to connect to server1");
                exit(0);
            }

            send_exp(sock_as_cli1, req, buf);
            
            recv_exp(sock_as_cli1, buf, expression);
            load1 = atoi(expression);
            printf("Load received from server1 with IP %s is: %d\n", inet_ntoa(serv1_addr.sin_addr), load1);
            close(sock_as_cli1);

            if ((sock_as_cli2 = socket(AF_INET, SOCK_STREAM, 0)) < 0)
            {
                perror("[-] Error in creating a socket\n");
                exit(0);
            }

            if ((connect(sock_as_cli2, (struct sockaddr *) &serv2_addr, sizeof(serv2_addr)) < 0))
            {
                perror("[-] Unable to connect to server2");
                exit(0);
            }

            send_exp(sock_as_cli2, req, buf);

            recv_exp(sock_as_cli2, buf, expression);
            load2 = atoi(expression);
            printf("Load received from server2 with IP %s is: %d\n", inet_ntoa(serv2_addr.sin_addr), load2);
            close(sock_as_cli2);
            t_intital = time(NULL);
        }

        if (flag == 0)
            flag = poll(&count_down, 1, 5000);
        else
            flag = poll(&count_down, 1, 5000-t_diff*1000);

        if (flag < 0)
        {
            perror("[-] Error in polling\n");
            exit(0);
        }
        else if (flag > 0)
        {
            cli_len = sizeof(cli_addr);
            newsockfd = accept(sock_as_serv, (struct sockaddr *) &cli_addr, &cli_len);
            if (fork() == 0)
            {
                close(sock_as_serv);
                if (load1 <= load2)
                {
                    printf("Sending request to server1 with IP %s\n", inet_ntoa(serv1_addr.sin_addr));
                    if ((sock_as_cli1 = socket(AF_INET, SOCK_STREAM, 0)) < 0)
                    {
                        perror("[-] Error in creating a socket\n");
                        exit(0);
                    }

                    if ((connect(sock_as_cli1, (struct sockaddr *) &serv1_addr, sizeof(serv1_addr)) < 0))
                    {
                        perror("[-] Unable to connect to server1");
                        exit(0);
                    }

                    send_exp(sock_as_cli1, "Send Time", buf);
                    
                    recv_exp(sock_as_cli1, buf, expression);
                    send_exp(newsockfd, expression, buf);
                    close(sock_as_cli1);
                }
                else
                {
                    printf("Sending request to server2 with IP %s\n", inet_ntoa(serv2_addr.sin_addr));
                    if ((sock_as_cli2 = socket(AF_INET, SOCK_STREAM, 0)) < 0)
                    {
                        perror("[-] Error in creating a socket\n");
                        exit(0);
                    }


                    if ((connect(sock_as_cli2, (struct sockaddr *) &serv2_addr, sizeof(serv2_addr)) < 0))
                    {
                        perror("[-] Unable to connect to server2");
                        exit(0);
                    }

                    send_exp(sock_as_cli2, "Send Time", buf);

                    recv_exp(sock_as_cli2, buf, expression);
                    send_exp(newsockfd, expression, buf);
                    close(sock_as_cli2);
                }

                close(newsockfd);
                exit(0);
            }
            close(newsockfd);
        }

        t_curr = time(NULL);
        t_diff = t_curr - t_intital;
    }

    close(sock_as_serv);
    return 0;
}
