//  ************* Time Client *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 3
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

// function to receive the expression in chunks of size atmost 100
void recv_exp(int sockfd, char *buf, char *expression)
{
    bzero(expression, 1000);
    while (1)
    {
        int n = recv(sockfd, buf, 100, 0);
        strcat(expression, buf);
        if (buf[n-1] == '\0')
            break;
    }
}

int main(int argc, char *argv[])
{
    int sockfd;
    struct sockaddr_in serv_addr;
    char buf[100], expression[1000];

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[-] Error in creating a socket\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    inet_aton("127.0.0.1", &serv_addr.sin_addr);
    serv_addr.sin_port = htons(atoi(argv[1]));

    if ((connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0))
    {
        perror("[-] Unable to connect to server");
        exit(0);
    }

    recv_exp(sockfd, buf, expression);
    printf("%s\n", expression);

    close(sockfd);
    return 0;
}