//  ************* Command Exection Server Concurrent TCP *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <dirent.h>

// function to print error
void error(char *err)
{
    perror(err);
    exit(0);
}

// to get the command either "cd" or "dir" or "pwd" by removing the white spaces
int cmd_given(char *s, char cm[5])
{
    int n = strlen(s);
    int char_start = 0, pos = 0, i;
    for (i = 0; i < n && pos < 4; i++)
    {
        if (s[i] == ' ' || s[i] == '\t' || s[i] == '\n')
        {
            if (char_start)
                break;
        }
        else
        {
            char_start = 1;
            cm[pos++] = s[i];
        }
    }
    cm[pos] = '\0';
    return i;
}

// getting the argument of the command by removing the leading and trailing white spaces
void get_cmd(char *s, int ind, char *cmd)
{
    int i = ind, n = strlen(s), j = n-1;
    int pos = 0;
    for (i; i < n; i++)
        if (!(s[i] == ' ' || s[i] == '\t' || s[i] == '\n'))
            break;

    for (j = n-1; j >= 0; j--)
        if (!(s[j] == ' ' || s[j] == '\t' || s[j] == '\n'))
            break;

    for (i; i <= j; i++)
    {
        cmd[pos++] = s[i];
    }
    cmd[pos] = '\0';
}

// function to send the expression in chunks of size atmost 50
void send_exp(int newsockfd, char *expression, char *buf, int flag)
{
    int len = strlen(expression);
    int i = 0, pos = 0, done = 0, dir = 0;
    // printf("received exp: %s\n", expression);
    while (pos < len)
    {
        bzero(buf, 50);
        while (i < 50)
        {
            buf[i++] = expression[pos++];
            if (expression[pos] == '\n' && flag)
            {
                dir = 1;
                break;
            }
            if (expression[pos] == '\0')
            {
                done = 1;
                break;
            }
        }

        if (done)
        {
            buf[i] = '\0';
            send(newsockfd, buf, strlen(buf)+1, 0);
            bzero(buf, 50);
            break;
        }
        if (dir)
        {
            buf[i] = '\n';
            send(newsockfd, buf, i+1, 0);
            bzero(buf, 50);
            break;
        }
        i = 0;
        send(newsockfd, buf, 50, 0);
    }
}

void recv_exp(int sockfd, char *buf, char *expression)
{
    bzero(expression, 1000);
    while (1)
    {
        int n = recv(sockfd, buf, 50, 0);
        strcat(expression, buf);
        if (buf[n-1] == '\0')
            break;
    }
}

int main()
{
    int sockfd, newsockfd;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    // buffer to use for send and receive
    char buf[50];
    char command_expression[1000], cmd_ex[1000]; // to manage the input commands

    // creating a new socket for the server
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        error("[-] Error in creating a socket\n");

    // setting the socket attributes
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(20000);

    // binding the socket to the port
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
        error("[-] Error to bind local address\n");

    // listening to the clients and starting the server
    listen(sockfd, 5);
    printf("Started Server\n");

    while (1)
    {
        clilen = sizeof(cli_addr);
        // accepting the request from the client
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0)
            error("[-] Error in accept\n");
        
        // forking to create a child for behaving like a concurrent server
        if (fork() == 0)
        {
            close(sockfd); // closing the sockfd of parent

            printf("Connected to client\n");

            send_exp(newsockfd, "LOGIN:", buf, 0); // sending the "LOGIN:" expression (given in the question)
            int n;

            recv_exp(newsockfd, buf, command_expression); // receiving in chunks
            strcpy(buf, command_expression);
            FILE *fp = fopen("users.txt", "r");
            int flag = 0;

            char name[30];
            // checking the users.txt file for matching the received username from client
            while (fscanf(fp, "%s", name) != EOF)
            {
                if (strcmp(name, buf) == 0)
                {
                    flag = 1;
                    break;
                }
            }

            fclose(fp);

            if (flag)
            {
                send_exp(newsockfd, "FOUND", buf, 0); // sending "FOUND" (given in question)
                
                bzero(command_expression, 1000);
                bzero(cmd_ex, 1000);

                int exit_client = 0;

                while (1)
                {
                    bzero(command_expression, 1000);
                    bzero(cmd_ex, 1000);
                    while (1)
                    {
                        // receiving the command from client in chunks
                        n = recv(newsockfd, buf, 50, 0);
                        if (strcmp(buf, "exit") == 0)
                        {
                            printf("Client Disconnected\n");
                            exit_client = 0;
                            break;
                        }

                        strcat(command_expression, buf); // concatenating the whole command, said by sir (max size = 200)

                        if (buf[n-1] == '\0')
                            break;
                        bzero(buf, 50);
                    }

                    if (exit_client)
                        break;

                    char cm[5];
                    int ind = cmd_given(command_expression, cm);
                    
                    if (strcmp(cm, "cd") == 0)
                    {
                        get_cmd(command_expression, ind, cmd_ex);

                        if (strcmp(cmd_ex, "") == 0)
                        {
                            strcpy(cmd_ex, "/home/");
                            strcat(cmd_ex, getenv("USER"));
                        }
                        
                        int ch = chdir(cmd_ex);
                        if (ch < 0)
                            send_exp(newsockfd, "####", buf, 0); // sending in chunks using the function defined above
                        else
                            send_exp(newsockfd, "Changed directory successfully", buf, 0); // sending in chunks using the function defined above
                    }
                    else if (strcmp(cm, "pwd") == 0)
                    {
                        char *ch = getcwd(command_expression, sizeof(command_expression));
                        if (!ch)
                            send_exp(newsockfd, "####", buf, 0); // sending in chunks using the function defined above
                        else
                            send_exp(newsockfd, command_expression, buf, 0); // sending in chunks using the function defined above
                    }
                    else if (strcmp(cm, "dir") == 0)
                    {
                        get_cmd(command_expression, ind, cmd_ex);
                        if (strcmp(cmd_ex, "") == 0)
                            strcpy(cmd_ex, "./");
                        DIR *dir = opendir(cmd_ex);

                        if (!dir)
                            send_exp(newsockfd, "####", buf, 0); // sending in chunks using the function defined above
                        else
                        {
                            bzero(command_expression, 1000);
                            struct dirent *entry;
                                while ((entry = readdir(dir)))
                                {
                                    strcat(command_expression, entry->d_name); // concatenating the directories, max size = 200 (said by sir)
                                    strcat(command_expression, "\n");
                                    send_exp(newsockfd, command_expression, buf, 1); // sending in chunks using the function defined above
                                    bzero(command_expression, 1000);
                                }

                                send(newsockfd, "", 1, 0);
                                closedir(dir);
                        }
                    }
                    else
                        send_exp(newsockfd, "$$$$", buf, 0); // sending in chunks using the function defined above
                }
            }
            else
                send_exp(newsockfd, "NOT-FOUND", buf, 0);

            // closign the connection with client
            close(newsockfd);
            exit(0);
        }

        // closing the connection with client in the parent
        close(newsockfd);
    }

    close(sockfd);
    return 0;
}