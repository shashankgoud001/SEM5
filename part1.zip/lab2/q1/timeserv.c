//  ************* Time Server UDP *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

int main()
{
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;

    // Creating a socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("[-] Error in Socket Creation");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr, 0, sizeof(cliaddr));

    // Setting the values of attributes
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(8181);

    // Binding the socket to unique local name
    if (bind(sockfd, (const struct sockaddr *) &servaddr, sizeof(servaddr)) < 0)
    {
        perror("[-] Error in Binding");
        exit(EXIT_FAILURE);
    }

    printf("[+] Server started\n");

    socklen_t len = sizeof(cliaddr);
    char buf[30];

    // creating a iterative server
    while (1)
    {
        bzero(buf, 30);
        // receiving request from client
        int n = recvfrom(sockfd, (char *)buf, 30, 0, (struct sockaddr*) &cliaddr, &len);
        buf[n] = '\0';
        printf("[+] Received request: %s\n", buf);

        // getting current time after the client request
        time_t time_raw;
        struct tm* curr_time;

        time(&time_raw);
        curr_time = localtime(&time_raw);

        strcpy(buf, asctime(curr_time));

        // sending the time to the server
        sendto(sockfd, (const char *)buf, strlen(buf)+1, 0, (const struct sockaddr*) &cliaddr, len);

        printf("[+] Served client request\n\n");
    }

    // closing the socket
    close(sockfd);

    return 0;
}