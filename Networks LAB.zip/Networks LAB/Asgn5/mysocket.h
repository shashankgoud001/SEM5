#ifndef __MYSOCKET_H
#define __MYSOCKET_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define SOCK_MyTCP SOCK_STREAM

typedef struct
{
    int sockfd;
    char* message;
    int len;
    int flags;
} MESSAGE;

typedef struct
{
    int sockfd;

} MyTCP;

int my_socket(int type);
int my_bind(MyTCP sockfd, struct sockaddr *addr, int addrlen);
int my_listen(MyTCP sockfd, int backlog);
int my_accept(MyTCP sockfd, struct sockaddr *addr, int *addrlen);
int my_connect(MyTCP sockfd, struct sockaddr *addr, int addrlen);
int my_send(MyTCP sockfd, void *buf, int len, int flags);
int my_recv(MyTCP sockfd, void *buf, int len, int flags);
int my_close(MyTCP sockfd);

#endif