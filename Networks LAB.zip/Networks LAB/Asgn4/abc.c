#include <time.h>
#include <stdio.h>

int main() {
    const char* time_str = "Mon Feb 13 19:23:17 2023";
        //                       0   10 
    // Parse the string into a struct tm
    struct tm timeinfo;
    strptime(time_str, "%a %b %d %H:%M:%S %Y", &timeinfo);
    
    // Convert struct tm to time_t
    time_t given_time = mktime(&timeinfo);
    printf("%d-",timeinfo.tm_mday);
    printf("%d-",timeinfo.tm_mon);
    printf("%d\n",timeinfo.tm_year);
    printf("%d:",timeinfo.tm_hour);
    printf("%d:",timeinfo.tm_min);
    printf("%d\n",timeinfo.tm_sec);
    // printf("%d",timeinfo.tm_hour);
    // Get current time
    time_t current_time = time(NULL);

    // Calculate time difference
    printf("%s\n",ctime(&given_time));
    printf("%s\n",ctime(&current_time));
    int diff_secs = difftime(given_time+3600, current_time);

    printf("Time difference is %d seconds\n", diff_secs);


    printf("%s:%s:%s:%s",date,time,IP,Port,h->)

    return 0;
}
