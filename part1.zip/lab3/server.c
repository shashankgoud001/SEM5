//  ************* Time Server *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 3
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

// function to send the expression in chunks of size atmost 50
void send_exp(int sockfd, char *expression, char *buf)
{
    int len = strlen(expression);
    int i = 0, pos = 0, done = 0;
    while (pos < len)
    {
        bzero(buf, 100);
        while (i < 100)
        {
            buf[i++] = expression[pos++];
            if (expression[pos] == '\0')
            {
                done = 1;
                break;
            }
        }

        if (done)
        {
            buf[i] = '\0';
            send(sockfd, buf, strlen(buf)+1, 0);
            break;
        }
        i = 0;
        send(sockfd, buf, strlen(buf)+1, 0);
    }
}

// function to receive the expression in chunks of size atmost 100
void recv_exp(int sockfd, char *buf, char *expression)
{
    bzero(expression, 1000);
    while (1)
    {
        int n = recv(sockfd, buf, 100, 0);
        strcat(expression, buf);
        if (buf[n-1] == '\0')
            break;
    }
}

int main(int argc, char *argv[])
{
    int sockfd, newsockfd;
    socklen_t clilen;
    struct sockaddr_in cli_addr, serv_addr;
    char buf[100], expression[1000];

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[-] Error in creating a socket\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(atoi(argv[1]));

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("[-] Error to bind local address\n");
        exit(0);
    }

    listen(sockfd, 5);
    srand(time(0));

    while (1)
    {
        clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        if (newsockfd < 0)
        {
            perror("[-] Accept error\n");
            exit(0);
        }

        recv_exp(newsockfd, buf, expression);

        if (strcmp(expression, "Send Load") == 0)
        {
            int random_number = rand() % 100 + 1;
            bzero(expression, 1000);
            sprintf(expression, "%d", random_number);
            send_exp(newsockfd, expression, buf);
            printf("Load sent: %d\n", random_number);
        }
        else if (strcmp(expression, "Send Time") == 0)
        {
            time_t time_raw;
            struct tm* curr_time;

            time(&time_raw);
            curr_time = localtime(&time_raw);

            strcpy(expression, asctime(curr_time));
            send_exp(newsockfd, expression, buf);
        }

        close(newsockfd);
    }

    close(sockfd);

    return 0;
}