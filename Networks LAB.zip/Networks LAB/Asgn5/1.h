#ifndef DAM
#define DAM

#include <stdio.h>



int sum(int a,int b);





#endif