#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

float numbers[100];
int tn = -1, to = -1;
char op[100];
int is_op = 1;

void push_num(float n)
{
    numbers[++tn] = n;
}

void push_op(char ch)
{
    op[++to] = ch;
}

float pop_num()
{
    return numbers[tn--];
}

char pop_op()
{
    return op[to--];
}

float infix_eval()
{
    float x, y;
    char ope;

    x = pop_num();
    y = pop_num();

    ope = pop_op();

    switch (ope)
    {
        case '+':
            return x+y;
        case '-':
            return y-x;
        case '*':
            return x*y;
        case '/':
            if (x == 0.0)
            {
                printf("\n ^^^^ Can not divide by 0 ^^^^\n");
                exit(0);
            }
            else    return y/x;
    }

    return 0;
}

int is_operator(char ch)
{
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
}

int precedence(char c)
{
    switch (c)
    {
        case '+':
            return 1;
        case '-':
            return 1;
        case '*':
            return 2;
        case '/':
            return 2;
        case '^':
            return 3;
    }
    return -1;
}

float eval(char exp[20])
{
    float output;

    for (int i = 0; exp[i] != '\0'; i++)
    {
        char c = exp[i];
        if (isdigit(c) != 0 || c == '.' || c == '-' && is_op == 1)
        {
            float num = 0;
            int flag = 0;
            int neg = 0;
            float decimal_part = 0, k = 0.1;
            if (c == '-')
            {
                neg = 1;
                i++;
                c = exp[i];
            }
            while (isdigit(c) || c == '.')
            {
                if (c == '.')
                {
                    flag = 1;
                    i++;
                    if (i == strlen(exp))
                        break;
                    c = exp[i];
                    continue;
                }
                if (flag == 0)
                    num = num*10 + c-'0';
                else
                {
                    decimal_part += k*(c-'0');
                    k/=10;
                }
                i++;
                if (i < strlen(exp))
                    c = exp[i];
                else break;
            }
            i--;
            float ins_val = num+decimal_part;
            
            if (neg)
                ins_val = -ins_val;

            push_num(ins_val);
            is_op = 0;
        }
        else if (c == '(')
        {
            is_op = 1;
            push_op(c);
        }
        else if (c == ')')
        {
            is_op = 1;
            while (op[to] != '(')
            {
                int r = infix_eval();
                push_num(r);
            }
            pop_op();
        }
        else if (is_operator(c))
        {
            is_op = 1;
            while (to != -1 && precedence(c) <= precedence(op[to]))
            {
                output = infix_eval();
                push_num(output);
            }
            push_op(c);
        }
    }

    while (to != -1)
    {
        output = infix_eval();
        push_num(output);
    }

    return pop_num();
}

int main()
{
    char exp[100];
    printf("enter the infix expression to evaluate: ");
    fgets(exp, 100, stdin);

    printf("%f\n", eval(exp));
    return 0;
}