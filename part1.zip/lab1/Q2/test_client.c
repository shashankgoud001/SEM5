//  ************* Evaluate Arithmatic Expression Client *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 1
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

int main()
{
    int sockfd;
    struct sockaddr_in serv_addr;
    char buf[100];

        if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        {
            perror("[-] Error in creating a socket\n");
            exit(0);
        }

        serv_addr.sin_family = AF_INET;
        inet_aton("127.0.0.1", &serv_addr.sin_addr);
        serv_addr.sin_port = htons(20000);


        // creating connection
        if ((connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0))
        {
            perror("[-] Unable to connect to server");
            exit(0);
        }
    while (1)
    {

        bzero(buf, 100);
        printf("Enter the expression: ");
        int flag = 0;
        int end_req = 0, compl_exp = 0;

        // sending chunks of data

            fgets(buf, 100, stdin);
            // printf("%s\n", buf);
            if (!flag)
            {
                if (strcmp(buf, "-1\n") == 0)
                {
                    end_req = 1;
                    // break;
                }
                
                flag = 1;
            }
        while (send(sockfd, buf, strlen(buf)+1, 0) > 0)
        {

            

            if (end_req)
                break;
            int l = strlen(buf);
            // if (buf[l-1] == '?')
            //     break;
            for (int i = 0; i < l; i++)
                if (buf[i] == '\n')
                {
                    compl_exp = 1;
                    break;
                }
            
            if (compl_exp)
                break;
            
            bzero(buf, 100);
            fgets(buf, 100, stdin);
            // printf("%s\n", buf);
            if (!flag)
            {
                if (strcmp(buf, "-1\n") == 0)
                {
                    end_req = 1;
                    // break;
                }
                
                flag = 1;
            }
        }

        if (end_req)
            break;
        
        printf("[+] Expression sent to server for evaluation\n");
        
        int rec_byte;
        char ans[100];
        ans[0] = '\0';
        bzero(buf, 100);

        // receiving the answer in chunks
        while ((rec_byte = recv(sockfd, buf, 100, 0)) > 0)
        {
            strcat(ans, buf);
            printf("Received bytes is: %d\n", rec_byte);
            int done = 0;
            for (int i = 0; i < strlen(buf); i++)
                if (buf[i] == '\n')
                {
                    done = 1;
                    break;
                }
            
            if (done)
                break;
            bzero(buf, 100);
        }

        printf("The value of the evaluated expression: %s\n", ans);
        
    }
        close(sockfd);

    return 0;
}