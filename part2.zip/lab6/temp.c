#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/ip_icmp.h>
#include <time.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>

unsigned short in_cksum(unsigned short *addr, int len)
{
    int nleft = len;
    int sum = 0;
    unsigned short *w = addr;
    unsigned short answer = 0;
    while (nleft > 1) {
        sum += *w++;
        nleft -= 2;
    }
    if (nleft == 1) {
        *(unsigned char *)(&answer) = *(unsigned char *)w;
        sum += answer;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return answer;
}

int main(int argc, char *argv[])
{
    if (argc < 2) 
        printf("Usage: %s hostname \n", argv[0]);

    struct hostent *host = gethostbyname(argv[1]);
    if (host == NULL) {
        printf("Unknown host %s \r ", argv[1]);
        exit(1);
    }

    struct icmphdr *icmp = (struct icmphdr *)malloc(sizeof(struct icmphdr));
    struct sockaddr_in dest;
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sock < 0) {
        perror("socket");
        exit(1);
    }

    icmp->type = ICMP_ECHO;
    icmp->code = 0;
    icmp->checksum = 0;
    icmp->un.echo.id = 0;
    icmp->un.echo.sequence = 0;
    icmp->checksum = in_cksum((unsigned short *)icmp, sizeof(struct icmphdr));

    dest.sin_family = AF_INET;
    dest.sin_addr = *(struct in_addr *)host->h_addr;

    printf("PING %s (%s): %d data bytes \r ", host->h_name, inet_ntoa(dest.sin_addr), sizeof(struct icmphdr) + strlen("Hi! Hello\n")

    char *data = "Hi! Hello\n";
    int datalen = strlen(data);
    char *packet = (char *)malloc(sizeof(struct icmphdr) + datalen);
    memcpy(packet, icmp, sizeof(struct icmphdr));
    memcpy(packet + sizeof(struct icmphdr), data, datalen);

    int n = sendto(sock, packet, sizeof(struct icmphdr) + datalen, 0, (struct sockaddr *)&dest, sizeof(dest));
    if (n < 0) {
        perror("sendto");
        exit(1);
    }

    char buf[1024];
    struct sockaddr_in from;
    int fromlen = sizeof(from);
    printf("before receive\n");
    n = recvfrom(sock, buf, 1500, 0, (struct sockaddr *)&from, &fromlen);
    if (n < 0) {
        perror("recvfrom");
        exit(1);
    }
    printf("after receive\n");

    struct iphdr *ip = (struct iphdr *)buf;
    icmp = (struct icmphdr *)(buf + (ip->ihl << 2));
    printf("ICMP from %s: type = %d, code = %d, id = %d, sequence = %d \r ", inet_ntoa(from.sin_addr), icmp->type, icmp->code, icmp->un.echo.id, icmp->un.echo.sequence);

    free(packet);

    return 0;
}