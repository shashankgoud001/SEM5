#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 5000
#define  BUF_SIZE 200
#define ROWS_LIMIT 40
#define MAX_LEN 1000
#define MAX_TOKENS 10
struct headers {
    char* method;
    char* url;
    char* protocol_version;
    char* host;
    char* connection;
    char* Date;
    char* Accept;
    char* Accept_Language;
    char* If_Modified_Since;
    char* Content_Language;
    char* Content_Length;
    char* Content_Type;
    char* Expires;
    char* Cache_Control;
    char* Last_Modified;
    int status;

};
void parse(char* request,struct headers* h){
    int r=0;
    char* value=(char*)malloc(100*sizeof(char));
    char* row=(char*)malloc(100*sizeof(char));
    char* val = (char*)malloc(100*sizeof(char));
    char** rows = (char**)malloc(30*sizeof(char*));
    row= strtok(request,"\n");
    while (row != NULL ) {
        rows[r++] = (char*)malloc(sizeof(char)*BUF_SIZE);
        strcpy(rows[r-1], row);
        row = strtok(NULL, "\n");
    }
    for(int i = 0;i<r;++i){
        if(i==0){
            val = strtok(rows[0]," ");
            h->method = val;
            val = strtok(NULL," ");
            h->url = val;
            val = strtok(NULL," ");
            h->protocol_version = val;
        }else{
            val = strtok(rows[i],": ");
            if(strcmp(val,"Host")==0){
                val = strtok(NULL,": ");
                h->host = val;
            }
            else if(strcmp(val,"Connection")==0){
                val = strtok(NULL,": ");
                h->connection = val;
            }
            else if(strcmp(val,"Date")==0){
                val = strtok(NULL,": ");
                h->Date = val;
            }
            else if(strcmp(val,"Accept")==0){
                val = strtok(NULL,": ");
                h->Accept = val;
            }
            else if(strcmp(val,"Accept-Language")==0){
                val = strtok(NULL,": ");
                h->Accept_Language = val;
            }
            else if(strcmp(val,"If-Modified-Since")==0){
                val = strtok(NULL,": ");
                h->If_Modified_Since = val;
            }
            else if(strcmp(val,"Content-language")==0){
                val = strtok(NULL,": ");
                h->Content_Language = val;
            }
            else if(strcmp(val,"Content-length")==0){
                val = strtok(NULL,": ");
                h->Content_Length = val;
            }
            else if(strcmp(val,"Content-type")==0){
                val = strtok(NULL,": ");
                h->Content_Type = val;
            }
            else if(strcmp(val,"Expires")==0){
                val = strtok(NULL,": ");
                h->Expires = val;
            }
            else if(strcmp(val,"Cache-Control")==0){
                val = strtok(NULL,": ");
                h->Cache_Control = val;
            }
            else if(strcmp(val,"Last-modified")==0){
                val = strtok(NULL,": ");
                h->Last_Modified = val;
            }
        }
    }

}
int main() {
    char host[BUF_SIZE];
    char connection[BUF_SIZE];
    char Date[BUF_SIZE];
    char Accept[BUF_SIZE];
    char file_path[BUF_SIZE];
    char method[5];
    char url[BUF_SIZE];
    int port = 80;
    // char input[SIZE] = "GET http://cse.iitkgp.ac.in/~agupta/networks/index.html HTTP/1.1";
    char input[SIZE] = "GET http://cse.iitkgp.ac.in/~agupta/networks/index.html html/1.1\nHost: www.example.com\nConnection: close\nAccept: text/html,pdf\nDate: 11/2/2023\nAccept-Language: en-us\nIf-Modified-Since: 2\nContent-length: 20\nAccept-Language: a,b,c";
    struct headers req ;
    parse(input, &req);
    printf("%s\t%s\t%s\n",req.method,req.url,req.protocol_version);
    printf("%s\n",req.host);
    printf("%s\n",req.connection);
    printf("%s\n",req.Accept);
    printf("%s\n",req.Date);
    printf("%s\n",req.If_Modified_Since);
    printf("%s\n",req.Content_Length);
    printf("%s\n",req.Accept_Language);


    // divide_string(input,"\n");

    return 0;

}