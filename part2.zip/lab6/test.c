#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netdb.h>

#define MAX_HOPS 30
#define PACKET_SIZE 64

unsigned short checksum(unsigned short *buf, int len);

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Usage: %s <hostname>\n", argv[0]);
        exit(1);
    }

    char *hostname = argv[1];
    char source_ip[32];
    struct sockaddr_in recv_addr;
    socklen_t recv_addr_len = sizeof(recv_addr);

    // create raw socket
    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sockfd < 0)
    {
        perror("socket");
        exit(1);
    }

    // set IP_HDRINCL socket option
    int optval = 1;
    if (setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &optval, sizeof(optval)) < 0)
    {
        perror("setsockopt");
        exit(1);
    }

    // set source IP address
    struct sockaddr_in local_addr;
    local_addr.sin_family = AF_INET;
    local_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if (bind(sockfd, (struct sockaddr *)&local_addr, sizeof(local_addr)) < 0)
    {
        perror("bind");
        exit(1);
    }
    if (getsockname(sockfd, (struct sockaddr *)&local_addr, &recv_addr_len) < 0)
    {
        perror("getsockname");
        exit(1);
    }
    strcpy(source_ip, inet_ntoa(local_addr.sin_addr));

    // set destination IP address
    struct hostent *host = gethostbyname(hostname);
    if (host == NULL)
    {
        perror("gethostbyname");
        exit(1);
    }
    struct in_addr dest_addr;
    memcpy(&dest_addr, host->h_addr_list[0], sizeof(struct in_addr));

    printf("traceroute to %s (%s), %d hops max\n", hostname, inet_ntoa(dest_addr), MAX_HOPS);

    for (int ttl = 1; ttl <= MAX_HOPS; ttl++)
    {
        // create IP header
        struct iphdr ip_header;
        ip_header.version = 4;
        ip_header.ihl = 5;
        ip_header.tos = 0;
        ip_header.tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr));
        ip_header.id = htons(getpid());
        ip_header.frag_off = 0;
        ip_header.ttl = ttl;
        ip_header.protocol = IPPROTO_ICMP;
        ip_header.check = 0;
        ip_header.saddr = inet_addr(source_ip);
        ip_header.daddr = dest_addr.s_addr;

        // calculate IP header checksum
        ip_header.check = checksum((unsigned short *)&ip_header, sizeof(struct iphdr));

        // create ICMP packet
        struct icmphdr icmp_packet;
        icmp_packet.type = ICMP_ECHO;
        icmp_packet.code = 0;
        icmp_packet.checksum = 0;
        icmp_packet.un.echo.id = getpid();
        icmp_packet.un.echo.sequence = ttl;

        // calculate ICMP packet checksum
        icmp_packet.checksum = checksum((unsigned short *)&icmp_packet, sizeof(struct icmphdr));

        // assemble packet
        char packet[PACKET_SIZE];
        memcpy(packet, &ip_header, sizeof(struct iphdr));
        memcpy(packet + sizeof(struct iphdr), &icmp_packet, sizeof(struct icmphdr));

        // send packet
        if (sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) < 0)
        {
            perror("sendto");
            exit(1);
        }

        // receive response
        char recv_buf[PACKET_SIZE];
        struct iphdr *recv_ip_header;
        struct icmphdr *recv_icmp_packet;

        int recv_bytes = recvfrom(sockfd, recv_buf, sizeof(recv_buf), 0, (struct sockaddr *)&recv_addr, &recv_addr_len);
        if (recv_bytes < 0)
        {
            perror("recvfrom");
            exit(1);
        }

        recv_ip_header = (struct iphdr *)recv_buf;
        recv_icmp_packet = (struct icmphdr *)(recv_buf + (recv_ip_header->ihl * 4));

        // print response
        char addr_str[32];
        inet_ntop(AF_INET, &recv_addr.sin_addr, addr_str, sizeof(addr_str));

        if (recv_icmp_packet->type == ICMP_ECHOREPLY)
        {
            printf("%2d %s\n", ttl, addr_str);
        }
        else if (recv_icmp_packet->type == ICMP_TIME_EXCEEDED)
        {
            printf("%2d %s (time exceeded)\n", ttl, addr_str);
        }
        else
        {
            printf("%2d unknown packet type %d\n", ttl, recv_icmp_packet->type);
        }

        // stop when we reach the destination
        if (recv_addr.sin_addr.s_addr == dest_addr.s_addr)
        {
            break;
        }
    }

    close(sockfd);

    return 0;
}

unsigned short checksum(unsigned short *buf, int len)
{
    unsigned int sum = 0;
    while (len > 1)
    {
        sum += *buf++;
        len -= 2;
    }
    if (len == 1)
    {
        sum += *(unsigned char *)buf;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return ~sum;
}