#include <stdio.h>
#include <unistd.h>

int main() {
    if (access("/home/venkata/Downloads/index.pdf", F_OK) == -1)
        printf("File does not exists and is not readable\n");
    else
        printf("File exists and is readable\n");
    return 0;
}