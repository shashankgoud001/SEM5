#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <dirent.h> 
#include <time.h>
#include <poll.h>
#define SIZE 100
#define MAX_SIZE 500
#define BUF_SIZE 50

void send_Message(int newsockfd,char buf[],char command[]){
	strcat(command,"\0");
	int l = strlen(command),i=0,j=0;
	while(j<l){
		bzero(buf,BUF_SIZE);
		i=0;
		while(i<BUF_SIZE&&j<=l){
			buf[i++]=command[j++];
		}
		if(j>=l) send(newsockfd,buf,strlen(buf)+1,0);
		else send(newsockfd,buf,strlen(buf),0);
	}
}

void send_Message_util(int newsockfd,char buf[],char command[]){
	strcat(command,"\0");
	bzero(buf,BUF_SIZE);
	int l = strlen(command),i=0,j=0;
	while(j<l){
		i=0;
		while(i<BUF_SIZE&&j<l){
			buf[i++]=command[j++];
		}
		send(newsockfd,buf,strlen(buf),0);
	}
}

void recieve_Message(int newsockfd,char buf[],char command[]){
	bzero(command,MAX_SIZE);
	bzero(buf,BUF_SIZE);
	int t;
	while((t=recv(newsockfd,buf,BUF_SIZE,0))>0){
		strcat(command,buf);
		if(buf[t-1]=='\0') break;
	}
}

int main(int argc,char* argv[])
{
	int			sockfd,sockfd_s1,sockfd_s2, newsockfd ;
	int			clilen,clilen_s1,clilen_s2;
	struct sockaddr_in	cli_addr,cli_addr_s1,cli_addr_s2, serv_addr,serv_addr_s1,serv_addr_s2;

	int i,x,r,t,sock_load_s1=5,sock_load_s2=2;
    time_t current_time,prev_time;
//
    if ((sockfd_s1 = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Unable to create socket\n");
		exit(0);
	}

	

	serv_addr_s1.sin_family	= AF_INET;
	inet_aton("127.0.0.1", &serv_addr_s1.sin_addr);
	serv_addr_s1.sin_port	= htons(atoi(argv[1]));

	if ((connect(sockfd_s1, (struct sockaddr *) &serv_addr_s1,
						sizeof(serv_addr_s1))) < 0) {
		perror("Unable to connect to server 1\n");
		exit(0);
	}
//
//
    if ((sockfd_s2 = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Unable to create socket\n");
		exit(0);
	}
	serv_addr_s2.sin_family	= AF_INET;
	inet_aton("127.0.0.1", &serv_addr_s2.sin_addr);
	serv_addr_s2.sin_port	= htons(atoi(argv[2]));

	if ((connect(sockfd_s2, (struct sockaddr *) &serv_addr_s2,
						sizeof(serv_addr_s2))) < 0) {
		perror("Unable to connect to server 2\n");
		exit(0);
	}
//


	char buf[SIZE],command[MAX_SIZE];	
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Cannot create socket\n");
		exit(0);
	}

	serv_addr.sin_family		= AF_INET;
	serv_addr.sin_addr.s_addr	= INADDR_ANY;
	serv_addr.sin_port		= htons(atoi(argv[3]));

	if (bind(sockfd, (struct sockaddr *) &serv_addr,
					sizeof(serv_addr)) < 0) {
		printf("Unable to bind local address\n");
		exit(0);
	}
    
    strcpy(command,"Send Time");
    send_Message(sock_load_s1,buf,command);
    recieve_Message(sock_load_s1,buf,command);
    printf("%s\n",command);
    
	listen(sockfd, 5); 
    struct pollfd fds;
    fds.fd = sockfd;
    fds.events = POLLIN;
    current_time = time(NULL);
    t = 5000;
	while (1) {
        bzero(command,MAX_SIZE);

        // poll
        r = poll(&fds, 1, t);
        // if(t/1000+current_time>time(NULL)+5){

        // }
        if(r<0){
            printf("Error\n");
        }
        else if (r == 1) {
            clilen = sizeof(cli_addr);
            newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,
                        &clilen) ;

            if (newsockfd < 0) {
                printf("Accept error\n");
                exit(0);
            }
            printf("Connection is Made\n");
            if (fork() == 0) {
                close(sockfd);	
                if(sock_load_s1<sock_load_s2){
                    strcpy(command,"Send Time");
                    send_Message(sock_load_s1,buf,command);
                    recieve_Message(sock_load_s1,buf,command);
                    printf("%s\n",command);
                    send_Message(newsockfd,buf,command);
                    printf("%s\n",command);
                }else{
                    strcpy(command,"Send Time");
                    send_Message(sock_load_s2,buf,command);
                    recieve_Message(sock_load_s2,buf,command);
                    printf("%s\n",command);
                    send_Message(newsockfd,buf,command);
                    printf("%s\n",command);
                }
                close(newsockfd);
                close(sockfd_s1);
                close(sockfd_s2);
                exit(0);
		    }
        } else {
            printf("Hello\n");
            printf("%d\n",time(NULL)-current_time);
            t = 5000;
            current_time = time(NULL);
        }
	}
	return 0;
}
			

