#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 500    
       

int empty(int top) {

   if(top == -1)
      return 1;
   else
      return 0;
}
   
int isfull(int top) {

   if(top == SIZE)
      return 1;
   else
      return 0;
}

char peek_char(char stack[],int top) {
   return stack[top];
}
float peek_float(float stack[],int top) {
   return stack[top];
}

void pop_char(char stack[],int top) {
	
   if(!empty(top)) {
      top = top - 1;   
   } else {
      printf("Stack is empty.\n");
   }
}
void pop_float(float stack[],int top) {
	
   if(!empty(top)) {
      top = top - 1;   
   } else {
      printf("Stack is empty.\n");
   }
}

void push_char(char stack[],int top, char data) {

   if(!isfull(top)) {
      top = top + 1;   
      stack[top] = data;
   } else {
      printf("Stack is full.\n");
   }
}
void push_float(float stack[],int top, float data) {

   if(!isfull(top)) {
      top = top + 1;   
      stack[top] = data;
   } else {
      printf("Stack is full.\n");
   }
}

int precedence (char c) {
    switch (c)
    {
        case '^' : return 3;
        case '/' : return 2;
        case '*' : return 2;
        case '+' : return 1;
        case '-' : return 1;
        default  : return 0;
    }
}

int isOperand (char c) {
	return ((c >= '0' && c <= '9')||c=='.');
}

char* infixToPostfix (char buf[]) { 
    char* res = (char*)malloc(SIZE*sizeof(char));
    int i=0,j=0,top = -1;
    char stack_char[SIZE];

	while(buf[i]!='\0'&&buf[i]!='\n'){
        if(buf[i]==' '){
            res[j++] = ' ';
            i++;
        }
		else if (isOperand(buf[i])) {
            res[j++] = buf[i++];
        }
		else if (buf[i] == '(') {
			push_char(stack_char,top,buf[i++]);
        }
		else if (buf[i] == ')') {
			while(peek_char(stack_char,top) != '(') {
				res[j++] = peek_char(stack_char,top);
				pop_char(stack_char,top);
			}
			pop_char(stack_char,top);
            i++;
		}
		else {
			while (!empty(top) && precedence(buf[i]) <= precedence(peek_char(stack_char,top))) {
				res[j++] = peek_char(stack_char,top);
				pop_char(stack_char,top);
			}
			push_char(stack_char,top,buf[i++]);
		}
	}

	while (!empty(top)) {
		res[j++] = peek_char(stack_char,top);
		pop_char(stack_char,top);
	}
	return res;
}


int main(){
    char temp[] = "(12.90+ 5.60) / 70.234\n";
    // printf("%s\n",infixtopostfix(temp));
    int n = strlen(temp);
    infixToPostfix(temp);
    return 0;
}