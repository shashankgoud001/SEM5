* https://stackoverflow.com/questions/15458438/implementing-traceroute-using-icmp-in-c

* https://www.masterraghu.com/subjects/np/introduction/unix_network_programming_v1.3/ch28lev1sec6.html

* https://courses.cs.vt.edu/cs4254/fall04/slides/raw_1.pdf

* https://www.pdbuchan.com/rawsock/icmp4.c

* https://www.pdbuchan.com/rawsock/icmp4_ll.c

* https://github.com/neelkanth13/ipv4-and-ipv6-raw-sockets/blob/master/icmpv4%20ping%20packet%20raw%20socket%20code.c

