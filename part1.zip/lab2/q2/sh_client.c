//  ************* Command Exection Client TCP *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

// function to print error
void error(char *err)
{
    perror(err);
    exit(0);
}

// function to send the expression in chunks of size atmost 50
void send_exp(int sockfd, char *expression, char *buf)
{
    int len = strlen(expression);
    int i = 0, pos = 0, done = 0;
    while (pos < len)
    {
        bzero(buf, 50);
        while (i < 50)
        {
            buf[i++] = expression[pos++];
            if (expression[pos] == '\0')
            {
                done = 1;
                break;
            }
        }

        if (done)
        {
            buf[i] = '\0';
            send(sockfd, buf, strlen(buf)+1, 0);
            break;
        }
        i = 0;
        send(sockfd, buf, strlen(buf)+1, 0);
    }
}

void recv_exp(int sockfd, char *buf, char *expression)
{
    bzero(expression, 1000);
    while (1)
    {
        int n = recv(sockfd, buf, 50, 0);
        strcat(expression, buf);
        if (buf[n-1] == '\0')
            break;
    }
}

int main()
{
    int sockfd;
    struct sockaddr_in serv_addr;
    // buffer to use for send and receive
    char buf[50];
    char command_expression[1000]; // to manage the input commands

    // creating a socket
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        error("[-] Error in creating a socket\n");

    // setting the attributes of address
    serv_addr.sin_family = AF_INET;
    inet_aton("127.0.0.1", &serv_addr.sin_addr);
    serv_addr.sin_port = htons(20000);

    // connecting to the server
    if ((connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0))
        error("[-] Unable to connect to server");

    recv_exp(sockfd, buf, command_expression); // receiving in chunks
    printf("%s ", command_expression);

    // reading the name of the user
    fgets(buf, 50, stdin);
    int n = strlen(buf);
    buf[n-1] = '\0';

    // sending the name (given in the question that max size is 25 and buffer max size is 50)
    send(sockfd, buf, strlen(buf)+1, 0);
    
    recv_exp(sockfd, buf, command_expression); // receiving in chunks

    // closing the client if the user is not found in the list of users
    if (strcmp(command_expression, "NOT-FOUND") == 0)
    {
        close(sockfd);
        printf("Invalid username\n");
        exit(0);
    }

    while (1)
    {
        printf("Enter a Command: ");
        fgets(command_expression, 1000, stdin); // reading the command
        n = strlen(command_expression);
        command_expression[n-1] = '\0';
        
        // sending the expression in chunks using "send_exp" function which is defined above
        send_exp(sockfd, command_expression, buf);

        if (strcmp(command_expression, "exit") == 0) // exiting if the command is "exit"
        {
            printf(":Session Terminated\n");
            close(sockfd);
            return 0;
        }

        int flag = 0;
        while (1)
        {
            n = recv(sockfd, buf, 50, 0); // receiving the the chunk
            if (strcmp(buf, "$$$$") == 0 && !flag)
            {
                printf("Invalid command\n");
                break;
            }
            else if (strcmp(buf, "####") == 0 && !flag)
            {
                printf("Error in running the command\n");
                break;
            }
            else
            {
                flag = 1;
                // fputs(buf, stdout); // printing the chunk
                for (int i = 0; i < n; i++)
                    printf("%c", buf[i]);
            }
            if (buf[n-1] == '\0')
            {
                printf("\n");
                bzero(buf, 50);
                break;
            }
        }
    }
    
    close(sockfd);

    return 0;
}