#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    time_t now;
    struct tm *time_info;

    time(&now);
    time_info = localtime(&now);
    time_info->tm_mday -= 2;
    mktime(time_info);

    printf("Local time minus 2 days: %s*", asctime(time_info));
	FILE *fp = fopen("fda/indexfj.html", "w");
	if (fp == NULL)
	{
		printf("Error opening file for writing index.html file\n");
		return 0;
	}
	fclose(fp);
    return 0;
}
