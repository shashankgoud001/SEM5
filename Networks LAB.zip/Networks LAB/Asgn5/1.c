#include "1.h"

int alpha = 20;
int beta = 30;

int sum(int a,int b){
    // alpha = 100;
    // beta = 20;
    alpha++;
    beta++;
    return alpha + beta;
}