#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LEN 1000
#define MAX_TOKENS 10



struct  http_request
{
    char url[MAX_LEN];
    int port;
    
    char method[MAX_LEN],path[MAX_LEN],host[MAX_LEN],date[MAX_LEN],if_mod[MAX_LEN],cont_type[MAX_LEN],con_lang[MAX_LEN];
    int connection;
    int content_len;
    char accept_lan[10][MAX_LEN],accept_req[10][MAX_LEN];
};

char** divide_string(char *input, char *delimiter) {
    char *token;
    char **tokens = (char**)malloc(MAX_TOKENS * sizeof(char*));
    int i = 0;


    token = strtok(input, delimiter);
    while (token != NULL && i < MAX_TOKENS) {
        tokens[i] = (char*)malloc(MAX_LEN * sizeof(char));
        strcpy(tokens[i], token);
        printf("%s\n",tokens[i]);
        i++;
        token = strtok(NULL, delimiter);
    }

    return tokens;
}
void par(char *input, struct http_request *req){
    int len = strlen(input);
     char **tokens = divide_string(input, "\n");
     //struct http_request req;
     char requestt[MAX_LEN];
    strcpy(requestt, tokens[0]);
    sscanf(requestt, "%s", req->method);
    sscanf(requestt, "%*s %s", req->url);
    sscanf(req->url, "http://%[^/]/%*[^:]:%d", req->host, &req->port);
    sscanf(req->url, "http://%*[^/]/%s", req->path);
      for(int i=1;tokens[i];i++){
        char *end = strstr(tokens[i], " ");
        char* token = strtok(tokens[i], ":");
        if(token!=NULL){
        if(strcmp(token, "Host")==0){
            strcpy(req->host, end+1);
            
        }
        else if(strcmp(token, "Connection")==0){
            if(strcmp(end+1, "close")==0){
                req->connection = 1;
            }
             //strcpy(req->connection ,end+1);
        }
        else if(strcmp(token, "Accept")==0){
            char ** t = divide_string(end+1, ",");
            int i=0;
            for(int i=0;t[i];i++){
                strcpy(req->accept_req[i], t[i]);
               
            }
             // strcpy(req->accept_req , end+1);
        }
        else if(strcmp(token, "Date")==0){
            strcpy(req->date ,end+1);
        }
        else if(strcmp(token, "Accept-Language")==0){
            char ** t = divide_string(end+1, ",");
            int i=0;
            for(int i=0;t[i];i++){
                strcpy(req->accept_lan[i], t[i]);
            }
         //strcpy(req->accept_lan , *end+1);
        }
        else if(strcmp(token, "If-Modifed-Since")==0){
 strcpy(req->if_mod ,end+1);
        }
        else if(strcmp(token, "Content-language")==0){
 strcpy(req->con_lang ,end+1);
        }
        else if(strcmp(token, "Content-length")==0){
        req->content_len =atoi(end+1);
        }
        else if(strcmp(token, "Content-type")==0){
 strcpy(req->cont_type ,end+1);
        }
            
        }
        
        
    }

}
int main() {
    char file_path[MAX_LEN];
    char method[5];
    char host[MAX_LEN];
    char url[MAX_LEN];
    int port = 80;
    char input[MAX_LEN] = "GET http://cse.iitkgp.ac.in/~agupta/networks/index.html\nHost: www.example.com\nConnection: close\nAccept: text/html,pdf\nDate: 11/2/2023\nAccept-Language: en-us\nIf-Modified-Since: 2\nContent-length: 20\nAccept-Language: a,b,c";
    struct http_request req ;
    par(input, &req);
   




    //printf("%d\n", req.);
    // char **tokens = divide_string(input, "\n");
    // struct request req;
    // char request[MAX_LEN] ;
    // strcpy(request, tokens[0]);
    // //strcpy(request, "GET http://10.98.78.2/docs/a1.pdf:8080");
    // //strcpy(request, "GET http://cse.iitkgp.ac.in/~agupta/networks/index.html");
    // sscanf(request, "%s", method);
    // sscanf(request, "%*s %s", url);
    // sscanf(url, "http://%[^/]/%*[^:]:%d", host, &port);
    // sscanf(url, "http://%*[^/]/%s", file_path);
    // printf("Method: %s\n", method);
    // printf("Host: %s\n", host);
    // printf("Port: %d\n", port);
    // printf("File Path: %s\n", file_path);
    
    return 0;
}
