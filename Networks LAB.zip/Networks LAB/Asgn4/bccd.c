#include <stdio.h>
#include <time.h>

int main() {
    const char* time_str = "Thu Jan 10 00:55:17 2023";

    // Parse the string manually
    struct tm timeinfo;
    sscanf(time_str, "%*s %d %d %d:%d:%d %d", timeinfo.tm_mon, &timeinfo.tm_mday, &timeinfo.tm_hour, &timeinfo.tm_min, &timeinfo.tm_sec, &timeinfo.tm_year);
    timeinfo.tm_mon--; // Adjust month value to range from 0 to 11
    timeinfo.tm_year -= 1900; // Adjust year value to number of years since 1900

    // Convert struct tm to time_t
    time_t given_time = mktime(&timeinfo);

    // Get current time
    time_t current_time = time(NULL);

    // Calculate time difference
    int diff_secs = difftime(given_time, current_time);

    printf("Time difference is %d seconds\n", diff_secs);

    return 0;
}
