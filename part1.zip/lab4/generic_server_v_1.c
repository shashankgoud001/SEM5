#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SIZE 5000
#define SIZE_MAX_ 1000
#define BUF_SIZE 100
// #define PORT 25000
#define LIMIT_ROWS_ 100

struct headers
{
    char *method;
    char *url;
    char *protocol_version;
    char *host;
    char *connection;
    char *Date;
    char *Accept;
    char *Accept_Language;
    char *If_Modified_Since;
    char *Content_Language;
    char *Content_Length;
    char *Content_Type;
    char *Expires;
    char *Cache_Control;
    char *Last_Modified;
    int status;
};
int count_number_of_bytes(char buf[], char filename[])
{
    bzero(buf, BUF_SIZE);
    FILE *infile;
    infile = fopen(filename, "rb");
    if (infile == NULL)
    {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    int t;
    int count = 0;
    printf("%s\n", filename);
    while ((t = fread(buf, 1, BUF_SIZE, infile)) > 0)
    {
        count += t;
    }
    fclose(infile);
    if (ferror(infile))
    {
        printf("Error reading file %s", filename);
    }
    printf("Count : %d\n", count);
    return count;
}
int send_any_file(int newsockfd, char buf[], char filename[])
{
    bzero(buf, BUF_SIZE);
    FILE *infile, *outfile;
    char outfilename[] = "output";
    infile = fopen(filename, "rb");
    outfile = fopen(outfilename, "wb");
    if (infile == NULL)
    {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    int t;
    while ((t = fread(buf, 1, BUF_SIZE, infile)) > 0)
    {
        send(newsockfd, buf, t, 0);
        fwrite(buf, 1, t, outfile);
    }
    fclose(infile);
    fclose(outfile);
    if (ferror(infile))
    {
        printf("Error reading file %s", filename);
    }
    bzero(buf, BUF_SIZE);
    return 1;
}

void parse(char *request, struct headers *h)
{
    h->Accept = h->Accept_Language = h->Cache_Control = h->connection = h->Content_Language = NULL;

    h->Content_Length = h->Content_Type = h->Date = h->Expires = h->host = h->If_Modified_Since = NULL;
    h->Last_Modified = h->method = h->protocol_version = h->url = NULL;
    int status = 0;
    int r = 0;
    char *value = (char *)malloc(SIZE_MAX_ * sizeof(char));
    char *row = (char *)malloc(SIZE_MAX_ * sizeof(char));
    char *val = (char *)malloc(SIZE_MAX_ * sizeof(char));
    char **rows = (char **)malloc(LIMIT_ROWS_ * sizeof(char *));
    row = strtok(request, "\r\n");
    while (row != NULL)
    {
        rows[r++] = (char *)malloc(sizeof(char) * BUF_SIZE);
        strcpy(rows[r - 1], row);
        row = strtok(NULL, "\r\n");
    }
    for (int i = 0; i < r; ++i)
    {
        if (i == 0)
        {
            val = strtok(rows[0], " ");
            h->method = val;
            val = strtok(NULL, " ");
            h->url = val;
            val = strtok(NULL, " ");
            h->protocol_version = val;
        }
        else
        {
            val = strtok(rows[i], ": ");
            if (strcmp(val, "Host") == 0)
            {
                val = strtok(NULL, ": ");
                h->host = val;
            }
            else if (strcmp(val, "Connection") == 0)
            {
                val = strtok(NULL, ": ");
                h->connection = val;
            }
            else if (strcmp(val, "Date") == 0)
            {
                val = strtok(NULL, ": ");
                h->Date = val;
            }
            else if (strcmp(val, "Accept") == 0)
            {
                val = strtok(NULL, ": ");
                h->Accept = val;
            }
            else if (strcmp(val, "Accept-Language") == 0)
            {
                val = strtok(NULL, ": ");
                h->Accept_Language = val;
            }
            else if (strcmp(val, "If-Modified-Since") == 0)
            {
                val = strtok(NULL, ": ");
                h->If_Modified_Since = val;
            }
            else if (strcmp(val, "Content-language") == 0)
            {
                val = strtok(NULL, ": ");
                h->Content_Language = val;
            }
            else if (strcmp(val, "Content-length") == 0)
            {
                val = strtok(NULL, ": ");
                h->Content_Length = val;
            }
            else if (strcmp(val, "Content-type") == 0)
            {
                val = strtok(NULL, ": ");
                h->Content_Type = val;
            }
            else if (strcmp(val, "Expires") == 0)
            {
                val = strtok(NULL, ": ");
                h->Expires = val;
            }
            else if (strcmp(val, "Cache-Control") == 0)
            {
                val = strtok(NULL, ": ");
                h->Cache_Control = val;
            }
            else if (strcmp(val, "Last-modified") == 0)
            {
                val = strtok(NULL, ": ");
                h->Last_Modified = val;
            }
        }
    }
    printf("came till\n");
}
void recieve_header(int newsockfd, char buf[], char response[], char extra[],int* l)
{
    int t, prev = 0, i = 0;
    int flag = 0;
    bzero(buf, BUF_SIZE + 1);

    while ((t = recv(newsockfd, buf, BUF_SIZE, 0)) > 0)
    {
        printf("%d\n",t);
        buf[t] = '\0';
        strcat(response, buf);
        for (i = 0; i < t; ++i)
        {
            if (prev == 0 && i == 0)
            {
                continue;
            }
            else
            {
                if (response[prev + i - 1] == '\n' && response[prev + i] == '\r')
                {
                    flag = 1;
                    break;
                }
            }
        }
        if (flag)
        {
            break;
        }
        prev += t;
        bzero(buf,BUF_SIZE);
    }

    if (flag)
    {

        if (i < t - 1)
        {
            printf("%d\n",i);
            i += 2;
            int j = 0;
            for (j = 0; j < t && i < t; ++j,i++)
            {
                printf("%c-",extra[j]);
                extra[j] = response[prev + i];
                response[prev + i] = '\0';
            }
            printf("\n");
            extra[j] = '\0';
            printf("%d\t%d\n",i,j);
            *l = j;
        }
        else
        {
            recv(newsockfd, buf, 1, 0);
            *l=0;
        }
    }
    else
    {
        extra[0] = '\0';

    }
    response[prev+t]='\0';
    // Length: %d\r\n\r\nillhkjgkjgkgk
}
void serve_client(struct headers *h, int newsockfd, char buf[])
{
    char *response = (char *)malloc(SIZE * sizeof(char));
    char *extra = (char *)malloc((BUF_SIZE + 5) * sizeof(char));
    int l=0;
    recieve_header(newsockfd, buf, response, extra,&l);
    printf("%s\t%d\n", response,strlen(response));
    // printf("extra : %s\t%d\n", extra, strlen(extra));
    printf("%d\n",l);
    bzero(buf, BUF_SIZE);
    int t, c = 0;
    FILE *outfile;
    char outfilename[] = "3.pdf";
    outfile = fopen(outfilename, "wb");
    int i = 0;
    if(l) i = fwrite(extra, l, 1, outfile);

    printf("val : %d\n",i);
    while ((t = recv(newsockfd, buf, BUF_SIZE, 0)) > 0)
    {
        fwrite(buf, 1, t, outfile);
    }
    fclose(outfile);
    printf("reached here\n");
    // recv(newsockfd, response, SIZE_MAX_, 0);
    // if(strcmp(h->method,"GET")==0){

    // }else if(strcmp(h->method,"POST")==0){

    // }
    // req.url = strcat(req.url)
    // printf("")
    // printf("%s\t%s\t%s\n",req.method,req.url,req.protocol_version);
    // printf("%s\n",req.host);
    // printf("%s\n",req.connection);
    // printf("%s\n",req.Accept);
    // if(req.Date)
    // printf("%s\n",req.Date);
    // printf("%s\n",req.If_Modified_Since);
    // printf("%s\n",req.Content_Length);
    // printf("%s\n",req.Accept_Language);
    char *name = (char *)malloc(100 * sizeof(char));
    // strcpy(name,".");
    // strcat(name,h->url);
    // int c = count_number_of_bytes(buf,name);
    // sprintf(response,"HTTP/1.1 200 OK\nContent-Type: application/pdf\nContent-Length: %d\r\n\r\n",c);
    // // // sprintf(response,"HTTP/1.1 200 OK\nContent-Type: image/jpeg\nContent-Length: %d\n\n",c);
    // send(newsockfd, response, strlen(response), 0);
    // send_any_file(newsockfd,buf,name);
}

int main()
{
    int sockfd, newsockfd;
    int clilen;
    struct sockaddr_in cli_addr, serv_addr;
    struct headers req;
    int i;
    char buf[SIZE_MAX_];
    bzero(buf, SIZE_MAX_);

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("Cannot create socket\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(21000);

    if (bind(sockfd, (struct sockaddr *)&serv_addr,
             sizeof(serv_addr)) < 0)
    {
        printf("Unable to bind local address\n");
        exit(0);
    }

    listen(sockfd, 5);

    while (1)
    {

        clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr,
                           &clilen);

        if (newsockfd < 0)
        {
            printf("Accept error\n");
            exit(0);
        }

        if (fork() == 0)
        {

            close(sockfd);

            serve_client(&req, newsockfd, buf);

            close(newsockfd);
            exit(0);
        }

        close(newsockfd);
    }
    return 0;
}
