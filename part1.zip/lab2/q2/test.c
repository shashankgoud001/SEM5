#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>

int main()
{
    char exp[100];
    // scanf("%[^\n]s", exp);
    // printf("%sa\n", exp);
    // DIR *dir;
    // getcwd(exp, 100);
    // printf("%s\n", exp);
    int x = chdir("/");
    // if (x < 0)
    //   printf("not changed\n");
    getcwd(exp, 100);
    printf("%s\n", exp);
    DIR *dir;
  struct dirent *entry;
  printf("user directory: %s\n", getenv("USER"));

  if ((dir = opendir("/")) == NULL)
    perror("opendir() error");
  else {
    puts("contents of root:");
    while ((entry = readdir(dir)) != NULL)
      printf("  %s", entry->d_name);
    closedir(dir);
  }
  printf("\n");
    return 0;
}