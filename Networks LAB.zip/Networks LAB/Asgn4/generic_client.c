#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SIZE 5000
#define SIZE_MAX_ 1000
#define  BUF_SIZE 100
// #define PORT 25000
#define LIMIT_ROWS_ 100
int count_number_of_bytes(char buf[],char filename[]){
    bzero(buf,BUF_SIZE);
    FILE *infile;
    infile = fopen(filename, "rb");
    if (infile == NULL) {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    int t;
    int count =0;
    printf("%s\n",filename);
    while ((t=fread(buf, 1,BUF_SIZE, infile)) >0) {
        count += t;
    }
    fclose(infile);
    if (ferror(infile)) {
        printf("Error reading file %s", filename);
    }
    printf("Count : %d\n",count);
    return count;
}
int send_any_file(int newsockfd,char buf[],char filename[]){
    bzero(buf,BUF_SIZE);
    FILE *infile, *outfile;
    char outfilename[] = "output";
    infile = fopen(filename, "rb");
    outfile = fopen(outfilename,"wb");
    if (infile == NULL) {
        printf("Error: could not open file %s", filename);
        return 1;
    }
    int t,c=0;
    while ((t=fread(buf, 1,BUF_SIZE, infile)) >0) {
        send(newsockfd,buf,t,0);
		// c+=t;
        fwrite(buf,1,t,outfile);
    }
	// printf("%d\n",c);
    fclose(infile);
    fclose(outfile);
    if (ferror(infile)) {
        printf("Error reading file %s", filename);
    }
    bzero(buf,BUF_SIZE);
    return 1;
}

int main()
{
	int			sockfd ;
	struct sockaddr_in	serv_addr;

	int i;
	char buf[1000];

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Unable to create socket\n");
		exit(0);
	}



	serv_addr.sin_family	= AF_INET;
	inet_aton("127.0.0.1", &serv_addr.sin_addr);
	serv_addr.sin_port	= htons(20000);


	if ((connect(sockfd, (struct sockaddr *) &serv_addr,
						sizeof(serv_addr))) < 0) {
		perror("Unable to connect to server\n");
		exit(0);
	}

	
	strcpy(buf,"PUT http://127.0.0.1:20000 output.pdf\r\nContent-Type: application/pdf\r\nContent-Length: 10000\r\n\r\n");
	// printf("%d\n",strlen(buf));
	send(sockfd, buf, strlen(buf), 0);
	// sleep(1);
	send_any_file(sockfd,buf,"wb.jpg");
	close(sockfd);
	return 0;

}

