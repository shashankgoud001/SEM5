#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/ip_icmp.h>
#include <time.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>

unsigned short in_cksum(unsigned short *addr, int len)
{
    int nleft = len;
    int sum = 0;
    unsigned short *w = addr;
    unsigned short answer = 0;
    while (nleft > 1) {
        sum += *w++;
        nleft -= 2;
    }
    if (nleft == 1) {
        *(unsigned char *)(&answer) = *(unsigned char *)w;
        sum += answer;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return answer;
}

int main(int argc, char *argv[])
{
    if (argc < 2) 
        printf("Usage: %s hostname \n", argv[0]);

    struct sockaddr_in addr;
    struct hostent *host;
    int sockfd;
    char *ip;
    char *hostname;
    char *packet;
    int packet_len;
    int i;
    int n;
    int on = 1;
    sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sockfd < 0) {
        perror("socket");
        exit(1);
    }

    struct icmp *icmp_packet;
    icmp_packet = (struct icmp *)malloc(sizeof(struct icmp));
    icmp_packet->icmp_type = ICMP_ECHO;
    icmp_packet->icmp_code = 0;
    icmp_packet->icmp_cksum = 0;
    icmp_packet->icmp_seq = 0;
    icmp_packet->icmp_id = 0;
    
    icmp_packet->icmp_cksum = in_cksum((unsigned short *)icmp_packet, sizeof(struct icmp));

    packet = (char *)icmp_packet;
    packet_len = sizeof(struct icmp);
    hostname = argv[1];
    host = gethostbyname(hostname);
    if (host == NULL) {
        perror("gethostbyname");
        exit(1);
    }
    ip = inet_ntoa(*(struct in_addr *)host->h_addr);
    printf("PING %s (%s): %d data bytes \n", hostname, ip, packet_len);
    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(ip);
    
    if (sendto(sockfd, packet, packet_len, 0, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("sendto");
        exit(1);
    }

    struct sockaddr_in from;
    socklen_t fromlen = sizeof(from);
    char buf[1024];
    n = recvfrom(sockfd, buf, sizeof(buf), 0, (struct sockaddr *)&from, &fromlen);
    if (n < 0) {
        perror("recvfrom");
        exit(1);
    }
    struct ip *ip_packet;
    ip_packet = (struct ip *)buf;
    struct icmp *icmp_reply;
    icmp_reply = (struct icmp *)(buf + (ip_packet->ip_hl << 2));
    if (icmp_reply->icmp_type == ICMP_ECHOREPLY) {
        printf("64 bytes from %s: icmp_seq=%d ttl=%d time=%d ms\n", inet_ntoa(from.sin_addr), icmp_reply->icmp_seq, ip_packet->ip_ttl, 0);
    }

    return 0;
}