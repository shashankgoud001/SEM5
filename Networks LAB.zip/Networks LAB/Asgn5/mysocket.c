#include "mysocket.h"

#define S_SLEEP_TIME 1
#define MSG_MAX_SIZE 1000
#define MAX_RECV_MSG_SIZE 5000

int send_counter;
int recv_counter;
int bytes_sent;
int bytes_recv;

MESSAGE send_message_buffer[10];
MESSAGE recv_message_buffer[10];

pthread_t send_thread;
pthread_t recv_thread;
pthread_mutex_t send_message_table_lock;
pthread_mutex_t recv_message_table_lock;
pthread_cond_t send_con;
pthread_cond_t recv_con;


void *send_message_S(void *param)
{
    MyTCP* sockfd = (MyTCP*) param;
    while (1)
    {
        sleep(S_SLEEP_TIME);
        pthread_mutex_lock(&send_message_table_lock);

        for(int i =0;i<send_counter;++i){
            bytes_sent += send(send_message_buffer[i].sockfd,send_message_buffer[i].message,send_message_buffer[i].len,send_message_buffer[i].flags);
            send_message_buffer[i].len = 0;
            send_message_buffer[i].flags = 0;
        }
        send_counter =0 ;
        pthread_cond_signal(&send_con);
        pthread_mutex_unlock(&send_message_table_lock);
    }
}
void *recv_message_R(void *param){
    MyTCP* sockfd = (MyTCP*) param;
    char* buf = (char*)malloc(MAX_RECV_MSG_SIZE*(sizeof(char)));
    int len,l,j,n,m;
    while(1){
        
        l = recv(sockfd->sockfd,buf,MAX_RECV_MSG_SIZE,0);
        lock(&recv_message_table_lock);


        while(recv_counter<10&&recv_counter&&l>0){
            m = recv_message_buffer[recv_counter-1].len;
            j = m;
            n = min(MAX_RECV_MSG_SIZE,m+l);
            while(j<n){
                recv_message_buffer[recv_counter-1].message[j] = buf[j-m];
                j++;
            }
            recv_message_buffer[recv_counter-1].len+=n-m;
            l -= n-m;
            bytes_recv += n-m;
            if(n==5000) recv_counter++;
        }
        pthread_cond_signal(&recv_con);
        unlock(&recv_message_table_lock);
    }
}

int my_socket(int type)
{
    if (type != SOCK_MyTCP)
    {
        perror("my_socket: type error");
        exit(1);
    }

    MyTCP sockfd;
    sockfd.sockfd = socket(AF_INET, SOCK_MyTCP, 0);
    if (sockfd.sockfd < 0)
    {
        perror("my_socket: socket error");
        exit(1);
    }

     for(int i = 0;i<10;++i){
        send_message_buffer[i].message = (char*)malloc(MSG_MAX_SIZE*sizeof(char));
        send_message_buffer[i].len = 0;
        send_message_buffer[i].flags = 0;
    }
    for(int i = 0;i<10;++i){
        recv_message_buffer[i].message = (char*)malloc(MAX_RECV_MSG_SIZE*sizeof(char));
        recv_message_buffer[i].len = 0;
        recv_message_buffer[i].flags = 0;
    }
    send_counter = 0;
    recv_counter = 0;
    bytes_sent = 0;
    bytes_recv = 0;

    pthread_attr_t send_attr, recv_attr;
    pthread_attr_init(&send_attr);
    pthread_attr_init(&recv_attr);


    pthread_mutex_init(&send_message_table_lock,NULL);
    pthread_mutex_init(&recv_message_table_lock,NULL);
    pthread_cond_init(&send_con,NULL);

    pthread_create(&(send_thread), &send_attr, send_message_S, &sockfd);
    pthread_create(&(recv_thread), &recv_attr, recv_message_R, &sockfd);
}

int my_bind(MyTCP sockfd, struct sockaddr *addr, int addrlen)
{
    return bind(sockfd.sockfd, addr, addrlen);
}

int my_listen(MyTCP sockfd, int backlog)
{
    return listen(sockfd.sockfd, backlog);
}

int my_accept(MyTCP sockfd, struct sockaddr *addr, int *addrlen)
{
    // MyTCP nesockfd = accept()
    return accept(sockfd.sockfd, addr, addrlen);
}

int my_connect(MyTCP sockfd, struct sockaddr *addr, int addrlen)
{
    return connect(sockfd.sockfd, addr, addrlen);
}


int my_send(MyTCP sockfd, void *buf, int len, int flags){
    int j,n;
    char* message = (char*)buf;
    while(len>0){

        pthread_mutex_lock(&send_message_table_lock);
        for(int i = 0;i<10&&len>0;++i){
            j = 0;
            n = min(len,1000);
            while(j<n){
                send_message_buffer[i].message[j] = message[i*1000+j]; 
                j++;
            }
            len -= n;
            send_message_buffer[i].len = n;
            send_message_buffer[i].flags = flags;
            send_message_buffer[i].sockfd = sockfd.sockfd;
            send_counter++;
        }
        pthread_cond_wait(&send_con,&send_message_table_lock);
        pthread_mutex_unlock(&send_message_table_lock);
    }
    len = bytes_sent;
    bytes_sent = 0;
    return len;
}

int my_recv(MyTCP sockfd, void *buf, int len, int flags){
    int j=0,n=len;
    char* message = (char*) buf;
    while(j<len){
        pthread_mutex_lock(&recv_message_table_lock);
        while(recv_counter==0) pthread_cond_wait(&recv_con,&recv_message_table_lock);
        for(int i = 0;i<recv_counter&&len>0;++i){
            j = 0;
            while(j<len){
            //    message[j] = recv_message_buffer[i][] 
            }
        }
        pthread_mutex_unlock(&recv_message_table_lock);
    }
}

int my_close(MyTCP sockfd)
{
    for(int i = 0;i<send_counter;++i){
        free(send_message_buffer[i].message);
        send_message_buffer[i].len = 0;
        send_message_buffer[i].flags = 0;
    }
    for(int i = 0;i<recv_counter;++i){
        free(recv_message_buffer[i].message);
        recv_message_buffer[i].len = 0;
        recv_message_buffer[i].flags = 0;
    }
    send_counter = 0;
    recv_counter = 0;
    
    
    pthread_join(send_thread, NULL);
    pthread_join(recv_thread, NULL);

    return close(sockfd.sockfd);
}