#include <stdio.h>
#include "1.h"

int main(){
    int t = sum(10,300);
    printf("%d\n",t);
    t = sum(10, 30);
    printf("%d\n", t);
    // printf("%d\t%d\n",alpha,beta);
    // socket(sockfd)
    // socket(newsockfd)
    return 0;
}