// #include <stdio.h>
// #include <stdlib.h>
// #include <unistd.h>
// #include <string.h>
// #include <time.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <arpa/inet.h>
// #include <netinet/in.h>

// int main()
// {
//     int sockfd, newsockfd;
//     struct sockaddr_in servaddr, cliaddr;

//     // Creating a socket
//     if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
//     {
//         perror("[-] Error in Socket Creation");
//         exit(EXIT_FAILURE);
//     }

//     // Setting the values of attributes
//     servaddr.sin_family = AF_INET;
//     servaddr.sin_addr.s_addr = INADDR_ANY;
//     servaddr.sin_port = htons(8000);

//     if (bind(sockfd, (const struct sockaddr *) &servaddr, sizeof(servaddr)) < 0)
//     {
//         perror("[-] Error in Binding");
//         exit(EXIT_FAILURE);
//     }

//     listen(sockfd, 5);
//     while (1)
//     {
//         socklen_t len = sizeof(cliaddr);
//         newsockfd = accept(sockfd, (struct sockaddr *) &cliaddr, &len);
//         if (newsockfd < 0)
//         {
//             perror("[-] Accept error");
//             exit(EXIT_FAILURE);
//         }

//         FILE *fp;
//         fp = fopen("index.html", "w");

//         char buf[100];
//         while (1)
//         {
//             bzero(buf, 100);
//             int n = recv(newsockfd, buf, 100, 0);
//             buf[n] = '\0';
//             if (n == 0)
//             {
//                 break;
//             }
//             for (int i = 0; i < n; i++)
//                 fprintf(fp, "%c", buf[i]);
//         }

//         fclose(fp);
//         close(newsockfd);

//         if (fork() == 0)
//         {
//             close(sockfd);
//             char *args[] = {"firefox", "index.html", NULL};
//             execvp("firefox", args);
//         }
//     }

//     close(sockfd);

//     return 0;
// }


//  ************* Time Server *************
/*
    Name      : Venkata Sai Suvvari
    Roll      :  20CS10067
    Assignment: 1
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>

int main()
{
    int sockfd, newsockfd;
    socklen_t clilen;
    struct sockaddr_in cli_addr, serv_addr;
    char buf[100];

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("[-] Error in creating a socket\n");
        exit(0);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(20000);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("[-] Error to bind local address\n");
        exit(0);
    }

    listen(sockfd, 5);

    while (1)
    {
        clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        if (newsockfd < 0)
        {
            perror("[-] Accept error\n");
            exit(0);
        }
        printf("connection established\n");

        FILE *fp;
        fp = fopen("index.html", "w");

        char buf[100];
        while (1)
        {
            bzero(buf, 100);
            int n = recv(newsockfd, buf, 100, 0);
            buf[n] = '\0';
            if (n == 0)
            {
                break;
            }
            for (int i = 0; i < n; i++)
                fprintf(fp, "%c", buf[i]);
        }

        fclose(fp);
        close(newsockfd);

        if (fork() == 0)
        {
            close(sockfd);
            char *args[] = {"firefox", "index.html", NULL};
            execvp("firefox", args);
        }

        close(newsockfd);
    }

    close(sockfd);

    return 0;
}