#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>

#define PORT 8080
int main(int argc, char const *argv[])
{
    int server_fd, new_socket; long valread;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    
    // char *hello = "HTTP/1.1 200 OK\nContent-Type: text/html\nContent-Length: 12\n\nHello world!";
    char *hello = "HTTP/1.1 404 OK\nContent-Type: text/html\nContent-Length: 12\n\n";
    // char *hello = "HTTP/1.1 200 OK\nContent-Type: text/html\nContent-Length: 130\n\n<!DOCTYPE html><html><head><title>Page Title</title></head><body><h1>My First Heading</h1><p>My first paragraph.</p></body></html>";
    
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("In socket");
        exit(EXIT_FAILURE);
    }
    

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
    
    memset(address.sin_zero, '\0', sizeof address.sin_zero);
    
    
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address))<0)
    {
        perror("In bind");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 10) < 0)
    {
        perror("In listen");
        exit(EXIT_FAILURE);
    }
    while(1)
    {
        printf("\n+++++++ Waiting for new connection ++++++++\n\n");
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)
        {
            perror("In accept");
            exit(EXIT_FAILURE);
        }
        
        char buffer[30000] = {0};
        valread = read( new_socket , buffer, 30000);
        printf("%s\n",buffer );
        write(new_socket , hello , strlen(hello));
        printf("------------------Hello message sent-------------------\n");
        close(new_socket);
    }
    return 0;
}

// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <errno.h>
// #include <unistd.h>
// #include <netdb.h> // for getnameinfo()

// // Usual socket headers
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>

// #include <arpa/inet.h>

// #define SIZE 1024
// #define BACKLOG 10  // Passed to listen()

// void report(struct sockaddr_in *serverAddress);

// void setHttpHeader(char httpHeader[])
// {
//     // File object to return
//     FILE *htmlData = fopen("index.html", "r");

//     char line[100];
//     char responseData[8000];
//     while (fgets(line, 100, htmlData) != 0) {
//         strcat(responseData, line);
//     }
//     // char httpHeader[8000] = "HTTP/1.1 200 OK\r\n\n";
//     strcat(httpHeader, responseData);
// }

// int main(void)
// {
//     char httpHeader[8000] = "HTTP/1.1 200 OK\r\n\n";

//     // Socket setup: creates an endpoint for communication, returns a descriptor
//     // -----------------------------------------------------------------------------------------------------------------
//     int serverSocket = socket(
//         AF_INET,      // Domain: specifies protocol family
//         SOCK_STREAM,  // Type: specifies communication semantics
//         0             // Protocol: 0 because there is a single protocol for the specified family
//     );

//     // Construct local address structure
//     // -----------------------------------------------------------------------------------------------------------------
//     struct sockaddr_in serverAddress;
//     serverAddress.sin_family = AF_INET;
//     serverAddress.sin_port = htons(8080);
//     serverAddress.sin_addr.s_addr = htonl(INADDR_LOOPBACK);//inet_addr("127.0.0.1");

//     // Bind socket to local address
//     // -----------------------------------------------------------------------------------------------------------------
//     // bind() assigns the address specified by serverAddress to the socket
//     // referred to by the file descriptor serverSocket.
//     bind(
//         serverSocket,                         // file descriptor referring to a socket
//         (struct sockaddr *) &serverAddress,   // Address to be assigned to the socket
//         sizeof(serverAddress)                 // Size (bytes) of the address structure
//     );

//     // Mark socket to listen for incoming connections
//     // -----------------------------------------------------------------------------------------------------------------
//     int listening = listen(serverSocket, BACKLOG);
//     if (listening < 0) {
//         printf("Error: The server is not listening.\n");
//         return 1;
//     }
//     report(&serverAddress);     // Custom report function
//     setHttpHeader(httpHeader);  // Custom function to set header
//     int clientSocket;

//     // Wait for a connection, create a connected socket if a connection is pending
//     // -----------------------------------------------------------------------------------------------------------------
//     while(1) {
//         clientSocket = accept(serverSocket, NULL, NULL);
//         send(clientSocket, httpHeader, sizeof(httpHeader), 0);
//         close(clientSocket);
//     }
//     return 0;
// }

// void report(struct sockaddr_in *serverAddress)
// {
//     char hostBuffer[INET6_ADDRSTRLEN];
//     char serviceBuffer[NI_MAXSERV]; // defined in `<netdb.h>`
//     socklen_t addr_len = sizeof(*serverAddress);
//     int err = getnameinfo(
//         (struct sockaddr *) serverAddress,
//         addr_len,
//         hostBuffer,
//         sizeof(hostBuffer),
//         serviceBuffer,
//         sizeof(serviceBuffer),
//         NI_NUMERICHOST
//     );
//     if (err != 0) {
//         printf("It's not working!!\n");
//     }
//     printf("\n\n\tServer listening on http://%s:%s\n", hostBuffer, serviceBuffer);
// }
// // #include <stdio.h>
// // #include <string.h>
// // int main(int argc, char *argv[])
// // {
// //     char aszXmlData[]="<body><name>amlendra</name><age>25</age></body>";
// //     char aszXmlRequest[250]= {0};
// //     char aszServiceMethod[]="applicationform.svc/getdetail";
// //     char aszRequest[150]= {0};
// //     char aszHostIp[30]="74.125.28.121";
// //     char aszPort[]="80";
// //     sprintf(aszRequest,"http://%s:%s/%s/ HTTP/1.1",aszHostIp,aszPort,aszServiceMethod);
// //     printf("Method and Resource path is below:\n\n\n");
// //     printf("%s",aszRequest);
// //     strcat(aszHostIp,":");
// //     strcat(aszHostIp,aszPort);
// //     printf("\n\nHOST header is below:\n\n\n");
// //     printf("%s",aszHostIp);
// //     sprintf(aszXmlRequest,"POST %s\r\nHost: %s\r\nContent-Type: application/xml\r\nContent-Length: %d\r\n\r\n%s\r\n",aszRequest,aszHostIp,strlen(aszXmlData),aszXmlData);
// //     printf("\n\n\nPOST Request which send to the server:\n\n");
// //     printf("%s",aszXmlRequest);
// //     return 0;
// // }

