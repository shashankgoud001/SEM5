#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h> 



int main(){
    // int d=20;
    // while(d--){

    // int ch=chdir("./../q1");
    // char cwd[256];
    // /*if the change of directory was successful it will print successful otherwise it will print not successful*/
    //  if (getcwd(cwd, sizeof(cwd)) == NULL)
    //   perror("getcwd() error");
    // else
    //   printf("current working directory is: %s\n", cwd);
    // // ch = chdir("q1");
    // if(ch<0)
    // printf("chdir change of directory not successful\n");
    // else
    // printf("chdir change of directory successful\n");
    // // }
    
    char a[100];
    strcpy(a,"");
    char* path = strtok(a, " ");
    if(path==NULL) printf("NUI\n");
    else
    printf("%s\t%lu\n",path,strlen(path));
	if(path != NULL) path = strtok(NULL, " ");
    if(path!=NULL) printf("%s\t%lu\n",path,strlen(path));
    // struct dirent *de;  // Pointer for directory entry 
  
    // // opendir() returns a pointer of DIR type.  
    // DIR *dr = opendir("."); 
  
    // if (dr == NULL)  // opendir returns NULL if couldn't open directory 
    // { 
    //     printf("Could not open current directory" ); 
    //     return 0; 
    // } 
  
    // // Refer http://pubs.opengroup.org/onlinepubs/7990989775/xsh/readdir.html 
    // // for readdir() 
    // while ((de = readdir(dr)) != NULL) 
    //         printf("%s\n", de->d_name); 

    return 0;

}