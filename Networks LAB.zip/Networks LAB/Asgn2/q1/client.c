#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

int main(){
  int clientSocket, nBytes;
  char buffer[1024];
  struct sockaddr_in serverAddr;
  socklen_t addr_size;
  int i;

  /*Create UDP socket*/
  clientSocket = socket(PF_INET, SOCK_DGRAM, 0);

  /*Configure settings in address struct*/
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_port = htons(7891);
  serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);  

  /*Initialize size variable to be used later on*/
  addr_size = sizeof serverAddr;

  for(i=0;i<5;i++){
    printf("Sending request to server...\n");
    sendto(clientSocket, "request", strlen("request"), 0, (struct sockaddr *) &serverAddr, addr_size);

    /* Wait for 3 seconds before trying to receive a response */
    fd_set rfds;
    struct timeval tv;
    int retval;
    FD_ZERO(&rfds);
    FD_SET(clientSocket, &rfds);
    tv.tv_sec = 3;
    tv.tv_usec = 0;
    retval = select(clientSocket+1, &rfds, NULL, NULL, &tv);

    if(retval == -1)
    {
        printf("Error in select()\n");
    }
    else if(retval)
    {
        /*Receive message from server*/
        nBytes = recvfrom(clientSocket, buffer, 1024, 0, NULL, NULL);
        printf("Received: %s\n", buffer);
        break; // exit the loop as we have received the response
    }
    else
    {
        printf("No data within 3 seconds.\n");
    }
  }
  if(i==5)
    printf("Exiting as no response received after 5 attempts\n");
  return 0;
}
